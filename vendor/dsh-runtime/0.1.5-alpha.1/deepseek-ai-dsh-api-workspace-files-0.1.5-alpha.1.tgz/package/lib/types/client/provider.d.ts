/**
 * The `file` protocol's provider: a workspace file's metadata as a stream of
 * `RemoteResult` frames.
 *
 * An address names the file in one of two scopes. A `session` address,
 * `dsh-resource://file/session/<sessionId>/<path>`, carries a path relative to
 * that Session's workspace root: the Host receives the relative path as-is and
 * resolves it against the root it holds. Only the Host's `stat.absolutePath`
 * selects the change-feed key; no Client Session summary is needed.
 * An `absolute` address, `dsh-resource://file/absolute/<path>`, carries no
 * Session and is read through the Session on screen. An address neither scope
 * resolves yields one failure frame — `workspace-file/unsupported-address` for
 * a string outside the grammar, `workspace-file/unknown-workspace` when the
 * absolute address has no current Session — and ends.
 *
 * The first frame is the file's `stat`; every Host-reported write yields the
 * metadata flagged `changed`; a reported disappearance, or a write while the
 * last stat had failed, runs `stat` again and flags what it finds; a reload
 * runs `stat` again and clears the flag. Failures travel as `ok: false` frames, never as thrown errors: the
 * Remote face does not reject, and anything thrown inside the stream is a
 * programming error the resource model lets surface. A failed stat does not end
 * the stream: the next write or reload stats again. One {@link ChangeFeed}
 * serves every open file of the Client.
 */
import type { ResourceProvider } from '@deepseek-ai/dsh-client-resources/client';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { ChangeFeed } from './change-feed.ts';
import type { WorkspaceFilesRemote } from './remote.ts';
/** The current Session used to authorize an absolute address. */
export interface SessionLookup {
    /**
     * The Session on screen, which an `absolute` address is read through.
     * @returns its id, or `undefined` while no Session is current.
     */
    current(): SessionId | undefined;
}
/**
 * Build the `file` provider over one Remote face, one change feed, and the Client's Session list.
 * @param remote - the Remote face carrying `workspaceFiles.stat`.
 * @param changes - the per-session change fan-out.
 * @param sessions - the current Session, read for absolute addresses on every open and reload.
 * @returns the provider to register into `ctx.resources`.
 */
export declare function createFileResourceProvider(remote: WorkspaceFilesRemote, changes: ChangeFeed, sessions: SessionLookup): ResourceProvider<'file'>;
//# sourceMappingURL=provider.d.ts.map