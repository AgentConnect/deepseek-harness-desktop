/**
 * Workspace file service: paged text reads, byte-window reads, stats, directory
 * listings, and the agent-write change feed inside one session's workspace
 * root, exposed as the `workspaceFiles` Remote namespace.
 *
 * Reads through `ctx.fs` are deliberately unconfined — the sandboxing backend
 * fences writes and edits only, and says so. Every constraint this service
 * needs is therefore its own, and there are four:
 *
 * 1. The path is authorized by containment in the session's workspace root.
 * 2. Containment is decided by {@link FileSystem.contains}, never by comparing
 *    path strings: `resolve` realpaths, so a prefix test cannot see a symlink
 *    that leaves the root. `lstat` rejects a link before that follow happens.
 * 3. Every cap is validated Config, changeable per deployment. A page is cut by
 *    lines and refused, not shortened, when its bytes exceed the byte cap; a
 *    listing is cut by entries and says so.
 * 4. Failures are one `RemoteError` per reason, declared in `./types`.
 *
 * A page is cut from `streamText`, which decodes and rejects non-UTF-8 as it
 * goes, so the file is read only up to the first character past the page and
 * never held whole in memory; the NUL scan runs on the page itself.
 *
 * This is NOT modelled on `session.openWorkspacePath`. That endpoint hands a
 * path to the local opener and leaves the effect on the machine; this one sends
 * file content across the wire, which is a different level of exposure.
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { Agent } from '@deepseek-ai/dsh-agent';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { WorkspaceByteRange, WorkspaceDirectoryListing, WorkspaceFileBytes, WorkspaceFileRange, WorkspaceFileStat, WorkspaceFileText, WorkspaceFileWatchFrame } from './types.ts';
export type * from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Host owner of the `workspaceFiles` Remote namespace. */
        workspaceFiles: WorkspaceFiles;
    }
}
/** Deployment caps on one page or one listing. */
export interface Config {
    /**
     * Inclusive byte cap on one page's text and on one byte window.
     *
     * A page above this fails; it is not shortened, because a silently cut page
     * reads as the whole page. A byte window asking for more is refused the same
     * way. The file itself has no size cap: a caller pages through it.
     */
    readonly maxBytes: number;
    /** Default and largest page size in lines; a request asking for more is refused. */
    readonly maxLines: number;
    /** Cap on returned directory entries; the rest is dropped and reported cut. */
    readonly maxEntries: number;
}
/** Host Remote service over the composed filesystem, confined to one workspace. */
export declare class WorkspaceFiles extends TypertRemoteService {
    private readonly config;
    static inject: string[];
    static Config: z<Config>;
    private readonly feed;
    /**
     * @param ctx - Host context carrying the filesystem and the sandbox policy.
     * @param config - deployment caps on one page or one listing.
     */
    constructor(ctx: Context, config: Config);
    /**
     * Read one page of lines from a UTF-8 text file inside the Agent's workspace.
     * @param agent - target Agent resolved from the Session identity on the wire.
     * @param path - workspace path, absolute or relative to the workspace root.
     * @param range - the line window; omitted fields take the page defaults.
     * @param signal - caller cancellation.
     * @returns the page, the file's version at the stat before it, and whether it reaches the last line.
     */
    read(agent: Agent, path: string, range: WorkspaceFileRange, signal: AbortSignal): Promise<WorkspaceFileText>;
    /**
     * Read one byte window of a regular file inside the Agent's workspace: raw
     * bytes, no text decoding and no binary rejection.
     * @param agent - target Agent resolved from the Session identity on the wire.
     * @param path - workspace path, absolute or relative to the workspace root.
     * @param range - the byte window; omitted fields take the window defaults.
     * @param signal - caller cancellation.
     * @returns the window in base64, the file's version and size at the stat before it, and whether it reaches the last byte.
     */
    readBytes(agent: Agent, path: string, range: WorkspaceByteRange, signal: AbortSignal): Promise<WorkspaceFileBytes>;
    /**
     * Report one regular file's identity, version, and size without its content.
     * @param agent - target Agent resolved from the Session identity on the wire.
     * @param path - workspace path, absolute or relative to the workspace root.
     * @param signal - caller cancellation.
     * @returns the file's absolute path, current version, and byte size.
     */
    stat(agent: Agent, path: string, signal: AbortSignal): Promise<WorkspaceFileStat>;
    /**
     * List the direct children of one directory inside the Agent's workspace.
     * @param agent - target Agent resolved from the Session identity on the wire.
     * @param path - workspace path, absolute or relative to the workspace root.
     * @param signal - caller cancellation.
     * @returns the directory's children in the backend's stable name order, bounded by the entry cap.
     */
    list(agent: Agent, path: string, signal: AbortSignal): Promise<WorkspaceDirectoryListing>;
    /**
     * Stream every `fs/observed` observation of a file inside the Agent's
     * workspace. Only Agent filesystem operations report here; the OS is not
     * watched.
     * @param agent - target Agent resolved from the Session identity on the wire.
     * @param signal - generation cancellation.
     * @returns `ready` once the Host observation queue is active and the workspace
     *   root is resolved, then queued and live observations in emission order.
     */
    changes(agent: Agent, signal: AbortSignal): AsyncIterable<WorkspaceFileWatchFrame>;
    /** Apply the page defaults and caps here, so the request never carries them implicitly. */
    private resolvePage;
    /** Apply the byte-window defaults and cap; a window above the cap is refused, not shortened. */
    private resolveWindow;
    /**
     * The workspace root comes from the policy, not from the backend's own cwd
     * default: the `minimal` preset shadows the host provider with a bare
     * `fs-local` whose cwd differs, and resolving explicitly makes the answer
     * the same whichever instance answers.
     */
    private workspaceRootOf;
    /**
     * Gates 1 and 2 up to the point where the path's own type is known. The
     * path is inspected before containment is decided, so a caller learns whether
     * an outside path exists and what kind it is before `outside-workspace`
     * refuses it; the caller is the Session's own owner, who can read the Host
     * through the Agent anyway, and the accepted cost buys one `lstat` gate for
     * every method instead of two resolution orders.
     */
    private inspect;
    /** Resolve an inspected path and refuse it unless the workspace contains it. */
    private confine;
    /**
     * All gates for a regular file, ending in the one stat that names its version
     * and size. The stat re-checks what `lstat` saw: the file may have gone or
     * changed kind in between.
     */
    private locateFile;
    private statOf;
    /** Stream the file as text and cut the page, classifying the backend's non-text refusal. */
    private cutPage;
}
export default WorkspaceFiles;
//# sourceMappingURL=index.d.ts.map