/**
 * The guide tab's body: a chain host, and the guide it falls back to.
 *
 * The chain is the replacement seam. A product with its own idea of what an
 * empty sidebar should say registers into `sidebar.right.tab.guide`, and its entry
 * takes the whole body; with no entry, or with every entry declining, the guide
 * below renders. The shipped guide is the owner's fallback rather than a chain
 * entry of its own, so there is always exactly one body and the shipped one
 * cannot be outvoted by accident.
 *
 * The shipped guide is a centred title, one line under it, and the entry boxes
 * every registered type contributed. Picking a box opens that type as a page in
 * this tab's place, so the guide is a doorway rather than a page that stays open.
 */
import type { ReactNode } from 'react';
import type { ObservableSnapshot } from '@deepseek-ai/dsh-client-store';
import type { InjectFace, PropsLocale, PropsRenderSlots, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { SidebarRightGuideBox } from '../../tab-registry.ts';
/** What the guide body needs from its host beyond the framework shares. */
export interface GuideInjected {
    /** The registry's guide entries in `order`; observable, so a type registering later appears. */
    readonly hooks: {
        readonly guideEntries: ObservableSnapshot<readonly SidebarRightGuideBox[]>;
    };
}
/** The guide body's composed props: the tab it draws, its chain child, its copy, and the entries. */
export type GuideBodyProps = PropsRuntime<'sidebar.right.pane.tab'> & PropsRenderSlots<'sidebar.right.tab.guide'> & PropsLocale<'sidebarRight'> & InjectFace<GuideInjected>;
/** The guide tab's body, replaceable through its chain child. */
export declare function GuideBody({ useTabInfo, useGuideEntries, renderSlotChain, t }: GuideBodyProps): ReactNode;
//# sourceMappingURL=GuideBody.d.ts.map