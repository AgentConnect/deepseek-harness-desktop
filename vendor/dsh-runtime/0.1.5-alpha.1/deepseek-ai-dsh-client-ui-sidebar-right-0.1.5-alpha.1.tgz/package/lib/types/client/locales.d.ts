/**
 * `sidebarRight` namespace dictionaries.
 *
 * Everything a user reads in this column is here, including the strings handed
 * to the docking kit — the kit renders no copy of its own, so its whole
 * vocabulary is this package's to own and translate.
 */
/** Simplified Chinese dictionary and key-set source of truth. */
export declare const zh: {
    'chrome.expand': string;
    'chrome.collapse': string;
    'chrome.toFullscreen': string;
    'chrome.exitFullscreen': string;
    'dock.emptyPane': string;
    'dock.splitPane': string;
    'dock.splitPaneDisabled': string;
    'dock.splitPaneNarrow': string;
    'dock.closeTab': string;
    'dock.addTab': string;
    'dock.dockFloat': string;
    'dock.closeFloat': string;
    'tab.guide.title': string;
    'tab.unavailable': string;
    'guide.lead': string;
    'guide.body': string;
};
/** Right-Sidebar dictionary key union. */
export type SidebarRightKey = keyof typeof zh;
/** English dictionary, checked against the Chinese key set. */
export declare const en: {
    'chrome.expand': string;
    'chrome.collapse': string;
    'chrome.toFullscreen': string;
    'chrome.exitFullscreen': string;
    'dock.emptyPane': string;
    'dock.splitPane': string;
    'dock.splitPaneDisabled': string;
    'dock.splitPaneNarrow': string;
    'dock.closeTab': string;
    'dock.addTab': string;
    'dock.dockFloat': string;
    'dock.closeFloat': string;
    'tab.guide.title': string;
    'tab.unavailable': string;
    'guide.lead': string;
    'guide.body': string;
};
//# sourceMappingURL=locales.d.ts.map