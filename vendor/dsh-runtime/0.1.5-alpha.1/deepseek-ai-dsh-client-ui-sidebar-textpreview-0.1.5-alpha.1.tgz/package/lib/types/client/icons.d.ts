/**
 * Glyphs this package draws that the shared icon set does not carry yet.
 * Same props contract as `@deepseek-ai/dsh-client-ui-primitives` icons, so a
 * shared replacement is a one-line import change.
 */
import type { IconProps } from '@deepseek-ai/dsh-client-ui-primitives';
/** Three text lines, the middle one turning back under itself. */
export declare const IconWrapOutline16: ({ size, className }: IconProps) => import("react").JSX.Element;
//# sourceMappingURL=icons.d.ts.map