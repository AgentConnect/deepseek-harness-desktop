import type { ReactNode } from 'react';
import type { InjectFace, PropsLocale, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { TextInjected } from './face.ts';
import type { TextPage, TextStore } from './store.ts';
/** The body's composed props: the tab, its navigation, the shared store and face, and copy. */
export type TextPreviewProps = PropsRuntime<'sidebar.right.pane.tab'> & PropsStore<TextStore> & InjectFace<TextInjected> & PropsLocale<'sidebarTextpreview'>;
/**
 * A page's lines. The Host joins a page's lines with `\n` without a terminator
 * and counts them, so a page past the file's last line (`lines: 0`) has none
 * and a page holding one empty line (`lines: 1`, `text: ''`) has one; a
 * trailing `\n` ends an empty last line.
 * @param page - the page's text and line count.
 * @returns the lines in order.
 */
export declare function linesOf(page: TextPage): string[];
/** One loaded page: the 1-based line it starts at, its text, and its line count. */
export interface LoadedPage extends TextPage {
    readonly offset: number;
}
/**
 * The loaded pages in file order.
 * @param pages - the store's page table.
 * @returns the pages, ascending by offset.
 */
export declare function loadedPages(pages: Record<number, TextPage>): LoadedPage[];
/**
 * The last line the loaded pages reach, by the Host's line counts; 0 before the first page.
 * @param pages - the loaded pages, ascending.
 * @returns the 1-based last loaded line.
 */
export declare function lastLineLoaded(pages: readonly LoadedPage[]): number;
/**
 * Scroll the body so one line sits at its top. A line the pages do not hold
 * leaves the body where it is.
 * @param body - the scrolling container; lines are positioned against it.
 * @param line - 1-based line.
 */
export declare function scrollToLine(body: HTMLElement, line: number): void;
/**
 * The text type's body, registered under `sidebar.right.pane.tab` as `text`.
 * @param props - composed slot props.
 * @returns the pages read so far with their controls, or a progress line.
 */
export declare function TextPreview({ useTabInfo, sessionId, useResource, useStore, actions, loadPage, reloadPages, t, }: TextPreviewProps): ReactNode;
//# sourceMappingURL=TextPreview.d.ts.map