/** Opt-in user Remote, carried only by the Host's authenticated Typert gateway. @module */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { MachineConnectionStatus } from './management-types.ts';
import type { MachineManagementRefusal } from './management.ts';
declare module '@deepseek-ai/dsh-typert-protocol' {
    interface RemoteErrorDetailsMap {
        'mcp/management-refused': {
            readonly reason: MachineManagementRefusal;
        };
    }
}
/** User administration of configured connections; no identity or key selectors cross this API. */
export declare class MachineManagementRemote extends TypertRemoteService {
    static inject: string[];
    private readonly manager;
    constructor(ctx: Context);
    private invoke;
    /** Read lifecycle state, including a disabled connection after Host restart.
     * @param id - Configured stable connection id.
     * @returns Public state without credentials or signer leases.
     */
    status(id: string): Promise<MachineConnectionStatus>;
    /** Disable locally and attempt trusted-endpoint Token revocation.
     * @param id - Configured stable connection id.
     * @returns Disabled state and independent remote revocation outcome.
     */
    disconnect(id: string): Promise<MachineConnectionStatus>;
    /** Revalidate C permission and target before explicit enablement.
     * @param id - Configured stable connection id.
     * @returns Actual SDK state after the new connection attempt.
     */
    enable(id: string): Promise<MachineConnectionStatus>;
}
export default MachineManagementRemote;
//# sourceMappingURL=management-remote.d.ts.map