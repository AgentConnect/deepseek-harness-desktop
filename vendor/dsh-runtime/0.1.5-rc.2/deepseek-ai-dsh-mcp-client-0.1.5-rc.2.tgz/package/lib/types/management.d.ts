/** Opt-in Host authority for configured MCP machine connections. @module */
import { Service, type Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { ManagedMachineConnection, MachineConnectionManager } from './management-types.ts';
import type { MachineHistoryRecoveryRule } from './machine-history.ts';
export type { MachineConnectionManager, MachineConnectionStatus } from './management-types.ts';
/** Installed Host plugins allowed to manage machine connections. Empty denies all managers. */
export interface Config {
    managerConsumers: string[];
    legacyRecovery?: MachineHistoryRecoveryRule[];
}
/** Closed management refusal reasons, safe for authenticated user responses. */
export type MachineManagementRefusal = 'manager_forbidden' | 'invalid_connection_id' | 'connection_unavailable' | 'operation_failed' | 'history_migration_required' | 'history_quarantine_required';
/** A management refusal containing no external error text. */
export declare class MachineManagementError extends Error {
    readonly code: MachineManagementRefusal;
    constructor(code: MachineManagementRefusal);
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        mcpConnections: McpConnections;
    }
}
/** Host-only registry; bound management capabilities are never model tools. */
export declare class McpConnections extends Service {
    static inject: string[];
    static Config: z<Config>;
    private readonly hostContext;
    private readonly records;
    private readonly managers;
    private readonly recovery;
    constructor(ctx: Context, config: Config);
    private authorize;
    /** Bind management to an actual installed Host plugin, rechecked on every operation.
     * @param context - Current Loader-owned manager context, never a consumer name.
     * @returns A capability restricted to public state and explicit lifecycle actions.
     */
    bindManager(context: Context): MachineConnectionManager;
    /** Register a configured connection from its actual MCP Loader context.
     * @param context - Installed MCP plugin owning the supervisor and signer session.
     * @param id - Stable Host connection id.
     * @param connection - Controls closed over the owner context and immutable configuration.
     * @returns Removal after the owner has quiesced its work.
     */
    register(context: Context, id: string, connection: ManagedMachineConnection): () => void;
}
export default McpConnections;
//# sourceMappingURL=management.d.ts.map