import type { MachineSentBearer } from './machine-history.ts';
/** Opaque bearer and its exact local partition; never a public connection description. */
export interface MachineToken {
    token: string;
    expiresAt: number;
    acquiredAt: number;
    scopes: string[];
    partition: string;
    issueId?: string;
}
/** Safe private-store facts; no credential or unauthenticated migration qualification is returned. */
export interface MachineStoreState {
    generation: number;
    active: boolean;
    migrationId?: string;
    quarantineEvidence?: string;
    historyUnavailable?: boolean;
}
/** Stores encrypted credentials separately for one persistent connection id. */
export declare class MachineConnectionStore {
    private readonly root;
    private readonly key;
    private readonly file;
    private readonly lock;
    private readonly historyPurpose;
    constructor(root: string, connectionId: string, key: () => Promise<Buffer>);
    private view;
    private authenticatedView;
    /** Read the fence and only authenticated history qualifications.
     * @returns Safe lifecycle facts; unavailable authentication is a closed gate, not empty history.
     */
    state(): Promise<MachineStoreState | undefined>;
    /** Migrate with the existing key; without it preserve the original row and expose only a closed gate.
     * @returns Authenticated migration facts or historyUnavailable, never a guessed complete empty state.
     */
    inspectHistory(): Promise<MachineStoreState | undefined>;
    private frame;
    private fingerprint;
    private historyAad;
    private migrate;
    private requireComplete;
    /** Explicit management enablement after fresh authorization.
     * @param generation - Exact disabled generation.
     * @param partition - Newly verified target and identity partition.
     * @param authorize - Recheck manager, owner and C permission inside the lock.
     * @param activationId - Unique activation rollback ownership.
     * @returns New active generation, preserving authenticated history.
     */
    enable(generation: number, partition: string, authorize: () => Promise<void>, activationId?: string): Promise<number>;
    /** Create only absent fresh state; a complete empty history is authenticated too.
     * @param partition - Full identity, key, policy and resource partition.
     * @returns Active generation or a closed legacy/credential failure.
     */
    open(partition: string): Promise<number>;
    private tokenWithKey;
    /** Read only a matching active generation with complete authenticated history.
     * @param generation - Expected generation.
     * @param partition - Exact partition.
     * @returns Current decrypted Token, if any.
     */
    token(generation: number, partition: string): Promise<MachineToken | undefined>;
    private decodeHistory;
    private encodeHistory;
    private tokenSource;
    private mergeToken;
    private seedCurrent;
    /** Persist material before the resource receives it.
     * @param generation - Expected active generation.
     * @param partition - Exact partition.
     * @param token - Actual outgoing bearer.
     * @param authorize - Recheck C after key resolution.
     * @returns Private authenticated records for the redactor only.
     */
    rememberSent(generation: number, partition: string, token: MachineToken, authorize: () => Promise<void>): Promise<MachineSentBearer[]>;
    /** Reload authenticated records, never treating a missing envelope as an empty complete history.
     * @returns Private records; never forward them to users or logs.
     */
    sentHistory(): Promise<MachineSentBearer[]>;
    /** Remove only fully elapsed receipt versions; keep enablement and retry metadata unchanged.
     * @param receipts - Exact expired versions from this process's monotonic observer.
     */
    pruneSentHistory(receipts: readonly string[]): Promise<void>;
    /** Record authenticated stopped-writer evidence without enabling anything.
     * @param migrationId - Exact authenticated migration.
     * @param evidenceRef - Trusted operator's reference.
     * @param authorize - Current manager check.
     */
    quarantineHistory(migrationId: string, evidenceRef: string, authorize: () => void): Promise<void>;
    /** Complete only authenticated, explicitly authorized recovery; preserve the active flag.
     * @param migrationId - Exact authenticated migration approved by the operator rule.
     * @param authorize - Check manager and complete isolation or all-prior-token invalidation evidence.
     */
    completeHistoryRecovery(migrationId: string, authorize: () => void): Promise<void>;
    /** Commit a new current Token only after retaining its predecessor.
     * @param generation - Expected generation.
     * @param value - New private Token.
     * @param authorize - Current C permission inside the lock.
     */
    commit(generation: number, value: MachineToken, authorize?: () => Promise<void>): Promise<void>;
    /** Final fence-only read after all asynchronous C/history work, immediately before dispatch or return.
     * @param generation - Expected generation.
     * @param partition - Exact partition.
     */
    assertCurrent(generation: number, partition: string): Promise<void>;
    /** Persist AS throttling.
     * @param generation - Current generation.
     * @param partition - Exact partition.
     * @param until - Retry deadline.
     */
    defer(generation: number, partition: string, until: number): Promise<void>;
    /** Read the shared retry deadline.
     * @param generation - Current generation.
     * @param partition - Exact partition.
     * @returns Earliest allowed retry.
     */
    retryAt(generation: number, partition: string): Promise<number>;
    /** Clear only the current Token while retaining authenticated history.
     * @param generation - Expected generation.
     * @param partition - Exact partition.
     */
    clear(generation: number, partition: string): Promise<void>;
    /** Disable without losing encrypted material; a missing key can only stop, never erase or complete history.
     * @param expectedGeneration - Optional conditional generation.
     * @param activationId - Optional activation ownership for stale rollback protection.
     */
    disable(expectedGeneration?: number, activationId?: string): Promise<void>;
    private check;
    private read;
    private transaction;
}
//# sourceMappingURL=machine-store.d.ts.map