/** Opaque bearer and its exact local partition; never a public connection description. */
export interface MachineToken {
    token: string;
    expiresAt: number;
    acquiredAt: number;
    scopes: string[];
    partition: string;
}
/** Stores encrypted credentials separately for one persistent connection id. */
export declare class MachineConnectionStore {
    private readonly root;
    private readonly key;
    private readonly file;
    private readonly lock;
    constructor(root: string, connectionId: string, key: () => Promise<Buffer>);
    /** Read the persistent fence, creating the connection only when absent.
     * @param partition - Full identity/resource/key/policy partition.
     * @returns Current connection generation.
     */
    open(partition: string): Promise<number>;
    /** Read only the matching active generation.
     * @param generation - Expected durable generation.
     * @param partition - Exact credential partition.
     * @returns Decrypted token, if one was committed.
     */
    token(generation: number, partition: string): Promise<MachineToken | undefined>;
    /** Atomically commit only while the connection is still active.
     * @param generation - Expected generation.
     * @param value - Secret token.
     * @param authorize - Rechecks the captured local permission and generation inside the commit lock.
     */
    commit(generation: number, value: MachineToken, authorize?: () => Promise<void>): Promise<void>;
    /** Check the durable disabled/generation fence immediately before a physical send.
     * @param generation - Expected generation.
     * @param partition - Exact credential partition.
     */
    assertCurrent(generation: number, partition: string): Promise<void>;
    /** Persist AS throttling across process instances.
     * @param generation - Current generation.
     * @param partition - Exact partition.
     * @param until - Wall-clock deadline; no retry is admitted before this value.
     */
    defer(generation: number, partition: string, until: number): Promise<void>;
    /** Read the shared Token retry deadline.
     * @param generation - Current generation.
     * @param partition - Exact partition.
     * @returns Earliest allowed attempt time.
     */
    retryAt(generation: number, partition: string): Promise<number>;
    /** Clear a rejected token without reviving a disabled generation.
     * @param generation - Expected generation.
     * @param partition - Exact credential partition.
     */
    clear(generation: number, partition: string): Promise<void>;
    /** Persist the disabled fence before any in-flight result can commit. */
    disable(): Promise<void>;
    private check;
    private read;
    private transaction;
}
//# sourceMappingURL=machine-store.d.ts.map