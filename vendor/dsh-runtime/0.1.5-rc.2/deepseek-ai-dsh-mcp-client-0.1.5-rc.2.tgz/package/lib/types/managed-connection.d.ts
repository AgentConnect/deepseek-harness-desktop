/** Own the machine signer session and actual SDK/tool lifecycle together. @module */
import type { Context } from '@deepseek-ai/cordis';
import type { StreamableHttpConfig } from './index.ts';
import type { ConnectionOutcome, ResolvedReconnectPolicy } from './connection.ts';
import type { MachineConnectionStatus } from './management-types.ts';
import type { MachineAuthentication } from './machine-types.ts';
import type { MachineHistoryRecoveryRule } from './machine-history.ts';
type MachineConfig = Omit<StreamableHttpConfig, 'authentication'> & {
    authentication: MachineAuthentication;
};
/** One configured connection, retained while explicitly disabled. */
export declare class ManagedConnection {
    private readonly ctx;
    private readonly config;
    private readonly reconnect;
    private machine;
    private connection;
    private readonly store;
    private stopped;
    private enabled;
    private chain;
    private remoteRevocation;
    private closing;
    private historyUnavailable;
    private readonly redactor;
    private readonly quarantine;
    constructor(ctx: Context, config: MachineConfig, reconnect: ResolvedReconnectPolicy);
    /** Start only if the persisted configuration is enabled.
     * @returns The real SDK's initial connection outcome, or a disabled no-op.
     */
    start(): Promise<ConnectionOutcome>;
    private serialize;
    private connect;
    /** Read durable enablement and real supervisor readiness without credentials.
     * @returns Public current connection facts.
     */
    status(): Promise<MachineConnectionStatus>;
    /** Persist a disabled fence before draining the actual SDK and tool registrations. */
    disconnect(): Promise<void>;
    /** Explicit re-enable obtains a fresh C lease and CAS-replaces only the observed disabled generation.
     * @param authorize - Current manager and installed owner check, repeated before committing enablement.
     * @param recovery - Exact operator-approved legacy rule from trusted Host configuration.
     */
    enable(authorize: () => void, recovery?: MachineHistoryRecoveryRule): Promise<void>;
    /** Process unload stops work but preserves the persisted enabled/disabled state. */
    dispose(): Promise<void>;
}
export {};
//# sourceMappingURL=managed-connection.d.ts.map