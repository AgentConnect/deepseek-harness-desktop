import type { MachineSentBearer } from './machine-history.ts';
/** Private callbacks used only by one connection's SDK bridge. */
export interface MachineOutputProtection {
    /** Pin credentials until the SDK operation finishes projecting its output. */
    begin(): () => void;
    /** Replace exact known bearer values in strings and JSON property names. */
    sanitize<T>(value: T): T;
    /** Recheck current connection, durable generation and C signer lease. */
    assertActive(): Promise<void>;
}
/** Refresh private history before projecting a machine SDK error.
 * @param protection - This connection's guard; absent for non-machine transports.
 * @param error - Untrusted SDK or registration failure.
 * @returns Original non-machine failure, or a local sanitized error without foreign cause/data.
 */
export declare function protectMachineFailure(protection: MachineOutputProtection | undefined, error: unknown): Promise<unknown>;
/** Bounded secret retention; no method exposes the retained bearer collection. */
export declare class MachineBearerRedactor {
    private readonly now;
    private readonly known;
    private readonly expired;
    private readonly clientIds;
    private operations;
    private bytes;
    constructor(now?: () => number);
    /** Register public identity facts obtained from the current C signer lease.
     * @param clientId - Exact CIMD identity confirmed by C.
     */
    registerIdentity(clientId: string): void;
    /** Retain the exact locally signed proof before the AS receives it.
     * @param assertion - Actual complete client assertion, never a public argument.
     */
    rememberAssertion(assertion: string): void;
    private maskClientAssertions;
    private prune;
    /** Retain an outgoing bearer for its full lifetime plus bounded network allowance.
     * @param value - Actual outgoing bearer, held only in this connection.
     * @param acquiredAt - Issuance attempt identity, distinguishing reuse from reissuance.
     * @param lifetime - Validated advertised Token lifetime in milliseconds.
     */
    remember(value: string, acquiredAt: number, lifetime: number): void;
    /** Merge a receipt without restarting its interval on every ordinary reload.
     * @param records - Authenticated private history read from the connection store.
     */
    observe(records: readonly MachineSentBearer[]): void;
    /** Take versions with a fully elapsed monotonic interval and no pinned SDK operation.
     * @returns Receipt ids only; no bearer values.
     */
    expiredReceipts(): string[];
    /** Acknowledge conditional persistence cleanup.
     * @param receipts - Successfully processed receipt versions.
     */
    acknowledgePruned(receipts: readonly string[]): void;
    /** Pin retention across SDK response parsing and asynchronous projection.
     * @returns Idempotent release after sanitization completes.
     */
    begin(): () => void;
    /** Clone JSON and redact exact values, preserving ordinary properties on key collisions.
     * @param value - SDK data or a diagnostic string from this connection.
     * @returns Sanitized data without mutating the SDK response.
     */
    sanitize<T>(value: T): T;
}
//# sourceMappingURL=machine-output.d.ts.map