/** Validate an exact HTTPS identity URL without rewriting its spelling.
 * @param value - Wire URL.
 * @returns Parsed URL after validation.
 */
export declare function machineUrl(value: string): URL;
/** Reject non-public DNS answers, including IPv4-mapped IPv6.
 * @param address - Resolved numeric address.
 * @returns Whether the destination is publicly routable.
 */
export declare function publicAddress(address: string): boolean;
/** Require the supported direct route from the process-wide Host proxy authority.
 * @param value - Exact HTTPS destination.
 * @returns Nothing when the Host policy permits the pinned direct lane.
 */
export declare function assertMachineDirectRoute(value: string | URL): void;
/** Send one request to the validated DNS address; HTTPS still verifies the original hostname.
 * @param input - Request URL or Request object.
 * @param init - Fetch-compatible request fields.
 * @returns A streaming response. Caller owns body cancellation.
 */
export declare function machineFetch(input: string | URL | Request, init?: RequestInit): Promise<Response>;
/** Test-only exact-origin loopback transport with an explicit ephemeral CA.
 * @param options - Exact HTTPS loopback origin and trusted test certificate.
 * @returns The same pinned transport with a bounded isolated test exception.
 */
export declare function createTestMachineFetch(options: {
    origin: string;
    ca: string;
}): typeof machineFetch;
/** Read a bounded JSON object without including response contents in errors.
 * @param response - Response to consume.
 * @returns Parsed object.
 */
export declare function machineJson(response: Response): Promise<Record<string, unknown>>;
//# sourceMappingURL=machine-http.d.ts.map