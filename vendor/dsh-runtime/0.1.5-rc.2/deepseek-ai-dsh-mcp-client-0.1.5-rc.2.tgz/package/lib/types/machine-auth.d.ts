import type { Context } from '@deepseek-ai/cordis';
import { machineFetch } from './machine-http.ts';
import type { MachineAuthentication } from './machine-types.ts';
/** Host-only connection authentication manager. SDK OAuth providers are deliberately absent. */
export declare class MachineAuthenticationSession {
    private readonly config;
    private readonly send;
    private readonly connectionOwner;
    private disposed;
    private closing;
    private disposal;
    private readonly controller;
    private binding;
    private readonly store;
    private readonly initialized;
    private readonly refreshTarget;
    private refreshing;
    private blocked;
    private tokenAttempts;
    private priorTokenMayRemain;
    private revocation;
    private monotonic?;
    private readonly startedAt;
    private readonly pending;
    constructor(ctx: Context, config: MachineAuthentication, endpoint: string, send?: typeof machineFetch);
    private releaseConnectionOwner;
    /** SDK fetch hook; one physical send, with no business-call replay.
     * @param input - SDK request URL.
     * @param init - SDK request fields.
     * @returns Authorized response, or a sanitized protocol error.
     */
    readonly fetch: (input: string | URL | Request, init?: RequestInit) => Promise<Response>;
    private dispatch;
    private assertBinding;
    private acquire;
    private issueWithRetry;
    private issue;
    /** Return public connection facts without secret references or credential values.
     * @returns Sanitized Host management status.
     */
    status(): {
        connectionId: string;
        state: string;
        generation: number;
        remoteRevocation: string;
        issuer?: string;
        resource?: string;
    };
    /** Stop work and quiesce requests. Explicit disconnect persists a disabled fence.
     * @param disconnect - Whether this is a management disconnect rather than process unload.
     */
    dispose(disconnect?: boolean): Promise<void>;
    private close;
}
//# sourceMappingURL=machine-auth.d.ts.map