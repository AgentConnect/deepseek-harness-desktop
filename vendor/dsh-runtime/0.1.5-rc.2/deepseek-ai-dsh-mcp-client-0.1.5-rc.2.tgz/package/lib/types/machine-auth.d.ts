import type { Context } from '@deepseek-ai/cordis';
import { machineFetch } from './machine-http.ts';
import type { MachineAuthentication } from './machine-types.ts';
import { MachineBearerRedactor } from './machine-output.ts';
import type { MachineOutputProtection } from './machine-output.ts';
interface AuthenticationStatus {
    connectionId: string;
    state: string;
    tokenReady: boolean;
    generation: number;
    remoteRevocation: string;
    issuer?: string;
    resource?: string;
}
/** Host-only connection authentication manager. SDK OAuth providers are deliberately absent. */
export declare class MachineAuthenticationSession {
    private readonly config;
    private readonly send;
    private readonly redactor;
    private readonly connectionOwner;
    private disposed;
    private closing;
    private disposal;
    private readonly controller;
    private binding;
    private readonly store;
    private readonly initialized;
    private readonly refreshTarget;
    private refreshing;
    private blocked;
    private tokenReady;
    private managementAuthorization;
    private readonly enableOperationId;
    private tokenExpiresAt;
    private tokenAttempts;
    private priorTokenMayRemain;
    private issuedSource;
    private revocation;
    private monotonic?;
    private readonly startedAt;
    private readonly pending;
    constructor(ctx: Context, config: MachineAuthentication, endpoint: string, send?: typeof machineFetch, explicitEnable?: {
        generation: number;
        authorize: () => void;
    }, redactor?: MachineBearerRedactor);
    private releaseConnectionOwner;
    /** SDK fetch hook; one physical send, with no business-call replay.
     * @param input - SDK request URL.
     * @param init - SDK request fields.
     * @returns Authorized response, or a sanitized protocol error.
     */
    readonly fetch: (input: string | URL | Request, init?: RequestInit) => Promise<Response>;
    private dispatch;
    /** Private bridge callbacks; bearer values never leave the redactor.
     * @returns Protection for this session's SDK metadata, results and diagnostics.
     */
    outputProtection(): MachineOutputProtection;
    private syncHistory;
    private assertBindingNow;
    private assertBinding;
    private acquire;
    private issueWithRetry;
    private issue;
    /** Return public connection facts without secret references or credential values.
     * @returns Sanitized Host management status.
     */
    status(): AuthenticationStatus;
    /** Complete explicit enablement after actual SDK readiness while the manager remains authorized. */
    completeEnable(): Promise<void>;
    /** Roll back only this enable operation, including an uncertain local write result. */
    rollbackEnable(): Promise<void>;
    /** Stop work and quiesce requests. Explicit disconnect persists a disabled fence.
     * @param disconnect - Whether this is a management disconnect rather than process unload.
     */
    dispose(disconnect?: boolean): Promise<void>;
    private close;
}
export {};
//# sourceMappingURL=machine-auth.d.ts.map