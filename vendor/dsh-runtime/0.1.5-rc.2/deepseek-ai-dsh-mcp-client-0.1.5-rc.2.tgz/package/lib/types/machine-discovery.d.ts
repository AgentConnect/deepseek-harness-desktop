import { machineFetch } from './machine-http.ts';
import type { MachineTarget } from './machine-types.ts';
/** Discover one exact MCP resource and select one compatible AS.
 * @param endpoint - Exact MCP resource URL.
 * @param selectedIssuer - Explicit selection when the resource lists multiple issuers.
 * @param cacheMs - Maximum lifetime of the validated discovery snapshot.
 * @param send - HTTPS transport; tests may inject isolated responses.
 * @returns Discovery evidence. This is not signing permission.
 */
export declare function discoverMachineTarget(endpoint: string, selectedIssuer?: string, send?: typeof machineFetch, cacheMs?: number): Promise<MachineTarget>;
//# sourceMappingURL=machine-discovery.d.ts.map