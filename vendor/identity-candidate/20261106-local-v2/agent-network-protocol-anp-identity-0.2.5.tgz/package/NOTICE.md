# Notices

Third-party components are listed in sbom.cdx.json.
