import type { IdentityReference, JsonValue, VerifiedRemoteDocument } from '@agent-network-protocol/anp-identity';
import type { ProviderLease } from '@agent-network-protocol/anp-identity/provider';
import type { PublicationBackend } from './publication-types.js';
import type { PapCallbackManagementOperations } from './pap-callback.js';
export interface DeviceManagementCredential {
    accessToken: string;
    deviceId: string;
    signingKeyId: string;
    audience?: string;
    operationBindings?: Record<string, Record<string, unknown>>;
}
/** The implementation must encrypt secrets at rest and partition by exact identity and service origin. */
export interface ManagementCredentialBroker {
    get(reference: IdentityReference, origin: string): Promise<DeviceManagementCredential | undefined>;
    set(reference: IdentityReference, origin: string, credential: DeviceManagementCredential): Promise<void>;
    reserveOperation(reference: IdentityReference, origin: string, operationId: string, body: Record<string, unknown>): Promise<Record<string, unknown>>;
}
export interface ManagedPublicationDriver extends PapCallbackManagementOperations {
    readonly documentId: string;
    readonly backend: PublicationBackend;
    readonly reference: IdentityReference;
    readVerifiedDocument(): Promise<VerifiedRemoteDocument>;
}
/** Create a device-authorized publication driver from a live Registry and an authenticated resolve.
 * @param input - Host custody, protected credentials and the fixed User Service origin.
 * @returns A driver bound to the server-resolved document id, never a user-supplied id.
 */
export declare function createManagedPublicationDriver(input: {
    reference: IdentityReference;
    origin: string;
    credentials: ManagementCredentialBroker;
    withNative<T>(operation: (native: ProviderLease) => Promise<T>): Promise<T>;
    fetch?: typeof fetch;
    /** Supplied by the Host installer to revoke this driver with its management Context and provider generation. */
    assertActive?: () => Promise<void>;
    /** Synchronous final epoch check immediately before physical sends and after body/native awaits. */
    assertCurrent?: () => void;
}): Promise<ManagedPublicationDriver>;
/** Registration fields supplied through the trusted Host management flow, never persisted in the catalog. */
export interface LocalRegistrationInput {
    handle: string;
    phone?: string;
    otp_code?: string;
    email?: string;
    invite_code?: string;
    name?: string;
    registration_operation_id?: string;
}
/** Register a locally held E1 Manifest and retain only a live, server-verified device credential.
 * @param input - Local identity, registration confirmation and protected broker.
 * @returns Public registration facts. No Access Token is returned.
 */
export declare function registerLocalIdentity(input: {
    reference: IdentityReference;
    origin: string;
    registration: LocalRegistrationInput;
    credentials: ManagementCredentialBroker;
    withNative<T>(operation: (native: ProviderLease) => Promise<T>): Promise<T>;
    fetch?: typeof fetch;
    managementAudience?: string;
    handleDomain?: string;
    assertActive?: () => void;
}): Promise<{
    did: string;
    deviceId: string;
    state: 'registered';
}>;
/** RFC 8785 serialization for native-produced JSON values.
 * @param value - Finite JSON data, with keys ordered by UTF-16 code units.
 * @returns Canonical UTF-8 text.
 */
export declare function canonicalManagementJson(value: JsonValue): string;
/** Construct the exact Web registration business projection; OTP and proof freshness are excluded.
 * @param input - Public local document and the explicit registration account/profile fields.
 * @returns Projection checked by the local native signer and User Service.
 */
export declare function webRegistrationProjection(input: {
    document: JsonValue;
    registration: LocalRegistrationInput;
    audience: string;
    handleDomain: string;
}): JsonValue;
//# sourceMappingURL=management-driver.d.ts.map