import type { IdentityReference } from '@agent-network-protocol/anp-identity';
import type { AccessAuthorizationRequest, AuthorizationDecision, AuthorizationExecution, AuthorizationGrant, AuthorizationOptions, AuthorizationRequest, AuthorizedLease, ControlledOperation, CreateAuthorizationRequest, DeletionReconciliation, RequestAccessInput, RequestCreateInput, VerifiedCaller } from './authorization-types.js';
export * from './authorization-types.js';
export declare class AuthorizationError extends Error {
    readonly code: string;
    constructor(code: string);
}
/** Compute at the Host boundary from the actual immutable operation, not a plugin-provided digest. */
export declare function freezeOperation(descriptor: Omit<ControlledOperation, 'fingerprint'>, canonicalPayload: unknown): ControlledOperation;
/** Persistent non-secret authorization ledger. Caller authentication belongs to the Host. */
export declare class AuthorizationEngine {
    #private;
    readonly stateRoot: string;
    readonly options: AuthorizationOptions;
    readonly statePath: string;
    constructor(stateRoot: string, options: AuthorizationOptions);
    initialize(): Promise<void>;
    subscribeRequestChanges(listener: () => void): () => void;
    requestCreate(verifiedCaller: VerifiedCaller, input: RequestCreateInput): Promise<CreateAuthorizationRequest>;
    requestAccess(verifiedCaller: VerifiedCaller, input: RequestAccessInput): Promise<AccessAuthorizationRequest>;
    getRequest(verifiedCaller: VerifiedCaller, requestId: string): Promise<AuthorizationRequest>;
    listRequests(): Promise<AuthorizationRequest[]>;
    markPrompted(requestId: string, expectedVersion?: number): Promise<void>;
    cancel(verifiedCaller: VerifiedCaller, requestId: string, expectedVersion: number): Promise<AuthorizationRequest>;
    decide(input: AuthorizationDecision): Promise<AuthorizationRequest>;
    reconcileCreation(requestId: string): Promise<CreateAuthorizationRequest>;
    listGrants(identity?: IdentityReference): Promise<AuthorizationGrant[]>;
    revoke(grantId: string, expectedVersion: number): Promise<AuthorizationGrant>;
    /** Manager-only explicit user retry. The old request and decision remain immutable history. */
    reauthorize(requestId: string, expectedVersion: number): Promise<AuthorizationRequest>;
    /** Call only for an authoritative disable/uninstall, never for a transient connection loss. */
    cancelPendingForConsumer(consumer: string): Promise<void>;
    /** Host-only bridge for legacy catalog grants, serialized against deletion and ordinary approvals. */
    withIdentityAccess<T>(identity: IdentityReference, callback: () => Promise<T>): Promise<T>;
    open(verifiedCaller: VerifiedCaller, grantId: string): Promise<AuthorizedLease>;
    admit(verifiedCaller: VerifiedCaller, lease: AuthorizedLease, requestedOperation: ControlledOperation, executionId: string): Promise<AuthorizationExecution>;
    assertExecutionActive(verifiedCaller: VerifiedCaller, lease: AuthorizedLease, executionId: string): Promise<void>;
    recordExecution(verifiedCaller: VerifiedCaller, executionId: string, status: 'succeeded' | 'failed' | 'unknown'): Promise<AuthorizationExecution>;
    getExecution(verifiedCaller: VerifiedCaller, executionId: string): Promise<AuthorizationExecution>;
    /** Prepare checks associations and may set the catalog deletion fence before native execution. */
    withIdentityDeletion(identity: IdentityReference, prepare: () => Promise<void>, execute: () => Promise<void>): Promise<void>;
    /** Host-only recovery of previously fenced deletions; absence alone never authorizes deletion. */
    reconcileDeletions(input: DeletionReconciliation): Promise<void>;
}
//# sourceMappingURL=authorization.d.ts.map