import type { ControlledOperation } from './authorization-types.js';
import type { UserOperation } from './user-client.js';
export declare function normalizeOperation(operation: UserOperation): Promise<{
    readonly frozen: ControlledOperation;
    readonly input: UserOperation;
}>;
//# sourceMappingURL=user-operation.d.ts.map