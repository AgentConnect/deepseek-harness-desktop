import { type PublicationRecord } from './publication-types.js';
import type { IdentityReference } from '@agent-network-protocol/anp-identity';
export declare const CATALOG_SCHEMA: "anp-identity-catalog/4";
export declare const CREATE_INTENT_SCHEMA: "anp-identity-create-intent/1";
export type CatalogEntryState = 'active' | 'deleting' | 'unclaimed';
export interface CatalogEntry {
    readonly identityId: string;
    readonly did: string;
    readonly storeId: string;
    readonly label?: string;
    readonly handle?: string;
    readonly createdByConsumer?: string;
    /** Durable create provenance, not an access grant. */
    readonly publication?: PublicationRecord;
    readonly creationOperationId?: string;
    readonly grantedConsumers: string[];
    readonly createdAt: string;
    readonly lastUsedAt: string;
    readonly state: CatalogEntryState;
}
export interface IdentityCatalog {
    readonly schema: typeof CATALOG_SCHEMA;
    readonly catalogGeneration: number;
    readonly entries: CatalogEntry[];
}
export interface CreateIntent {
    readonly schema: typeof CREATE_INTENT_SCHEMA;
    readonly requestId: string;
    readonly consumer: string;
    readonly label?: string;
    readonly handle?: string;
    readonly createdAt: string;
    readonly baselineIdentityIds: string[];
    readonly reference?: IdentityReference;
    /** User-confirmed creation never implies access. */
    readonly authorizationMode?: 'user';
}
export type CatalogFaultPoint = 'before_backup_temp_write' | 'after_backup_temp_sync' | 'after_backup_rename' | 'before_catalog_temp_write' | 'after_catalog_temp_sync' | 'after_catalog_rename' | 'before_intent_temp_write' | 'after_intent_temp_sync' | 'after_intent_rename';
export interface CatalogOptions {
    readonly fault?: (point: CatalogFaultPoint) => void;
    readonly lockTimeoutMs?: number;
}
/** Non-secret DSH metadata with atomic writes and a cross-process lock. */
export declare class CatalogStore {
    #private;
    readonly stateRoot: string;
    readonly catalogPath: string;
    readonly intentsRoot: string;
    readonly lockPath: string;
    readonly nativeCreateLockPath: string;
    constructor(stateRoot: string, options?: CatalogOptions);
    initialize(): Promise<void>;
    load(): Promise<IdentityCatalog>;
    mutate(operation: (catalog: IdentityCatalog) => IdentityCatalog, expectedGeneration?: number): Promise<IdentityCatalog>;
    replace(catalog: IdentityCatalog): Promise<IdentityCatalog>;
    writeIntent(intent: CreateIntent): Promise<void>;
    reserveIntent(intent: CreateIntent): Promise<void>;
    commitIntent(requestId: string): Promise<CatalogEntry>;
    updateIntent(requestId: string, operation: (intent: CreateIntent) => CreateIntent): Promise<CreateIntent>;
    readIntent(requestId: string): Promise<CreateIntent>;
    listIntents(): Promise<CreateIntent[]>;
    deleteIntent(requestId: string): Promise<void>;
    withNativeCreateLock<T>(operation: () => Promise<T>): Promise<T>;
    private withCatalogLock;
    private intentPath;
    private writeCatalog;
    private writeJsonAtomic;
    private writeBytesAtomic;
}
export declare function emptyCatalog(): IdentityCatalog;
export declare function entryReference(entry: CatalogEntry): IdentityReference;
export declare function findEntry(catalog: IdentityCatalog, reference: IdentityReference): CatalogEntry | undefined;
export declare function normalizeHandle(value: string): string;
//# sourceMappingURL=catalog.d.ts.map