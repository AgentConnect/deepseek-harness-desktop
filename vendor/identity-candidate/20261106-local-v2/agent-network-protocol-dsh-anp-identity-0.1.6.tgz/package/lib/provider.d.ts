/** Native ANP Identity Provider registration for the Host-only DSH service. */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type NativeProviderRegistration } from './provider-api.js';
export declare const name = "anp-identity-native-provider";
export declare const inject: string[];
export interface Config {
    readonly stateRoot?: string;
    readonly rootKeyProvider: 'keyring' | 'local-file' | 'env' | 'injected';
    /** Keyring uses `service/account`; env uses the variable name; injected uses the key id. */
    readonly rootKeyProviderId?: string;
    readonly keyringFallbackToLocalFile?: boolean;
    /** Programmatic Host injection only. Never place this value in Loader YAML. */
    readonly injectedRootKey?: Buffer;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
export declare function openNativeProvider(config: Config): Promise<NativeProviderRegistration>;
//# sourceMappingURL=provider.d.ts.map