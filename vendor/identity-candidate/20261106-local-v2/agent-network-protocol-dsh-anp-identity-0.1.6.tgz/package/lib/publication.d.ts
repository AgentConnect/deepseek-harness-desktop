import type { IdentityReference } from '@agent-network-protocol/anp-identity';
import type { ProviderLease } from '@agent-network-protocol/anp-identity/provider';
import { CatalogStore } from './catalog.js';
import { type PublicationBackend, type PublicationConfig, type PublicationRecord, type OAuthClientIdentity } from './publication-types.js';
export declare class PublicationCoordinator {
    readonly store: CatalogStore;
    readonly host: {
        withNative<T>(operation: (native: ProviderLease) => Promise<T>): Promise<T>;
    };
    constructor(store: CatalogStore, host: {
        withNative<T>(operation: (native: ProviderLease) => Promise<T>): Promise<T>;
    });
    status(reference: IdentityReference): Promise<OAuthClientIdentity>;
    requirePublished(reference: IdentityReference): Promise<PublicationRecord>;
    publish(reference: IdentityReference, raw: PublicationConfig, backend: PublicationBackend, assertActive: () => Promise<void>): Promise<OAuthClientIdentity>;
    private materials;
    private readBack;
    private entry;
    private save;
}
//# sourceMappingURL=publication.d.ts.map