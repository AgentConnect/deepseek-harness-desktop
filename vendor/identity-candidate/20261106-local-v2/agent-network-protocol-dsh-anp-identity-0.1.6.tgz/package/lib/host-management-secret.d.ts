import type { CredentialProvider } from '@deepseek-ai/dsh-credentials';
/** The actual Host credential service; reference and environment resolution are deliberately absent. */
export interface HostManagementSecretContext {
    readonly credentials?: Pick<CredentialProvider, 'readRecord' | 'modifyRecord'> | undefined;
}
/** Stable Host partition and a current observation of protected broker state. */
export interface HostManagementSecretOptions {
    context: HostManagementSecretContext;
    /** Absolute, stable broker ciphertext directory, also checked by hasExistingCiphertext; normalize aliases in the installer. */
    stateRoot: string;
    /** Stable Host bootstrap identifier, never a request id; changing it requires an independent broker directory. */
    bootstrapId: string;
    /** Recheck actual encrypted broker state while the credential record is exclusively locked. */
    hasExistingCiphertext(): Promise<boolean>;
    /** The installer may reject a revoked Host context; service proxies are not generation identifiers. */
    assertActive?(): void | Promise<void>;
}
/** Host-only key access; callers must clear each returned buffer after their cryptographic operation. */
export interface HostManagementSecret {
    /** Return a new 32-byte buffer after an exclusive current-record check. */
    getKey(): Promise<Buffer>;
    /** Revoke future access and reject an in-flight result before it reaches the broker. */
    dispose(): void;
}
/** Stable failure without provider errors, paths, records or secret material. */
export declare class HostManagementSecretError extends Error {
    readonly name = "HostManagementSecretError";
    readonly code = "credential_unavailable";
    constructor();
}
/**
 * Resolve one management-broker key through atomic credential-record operations.
 * The provider must implement exclusive read/decide/write; credentials-local supplies a cross-process lock.
 * Existing records are never rewritten. Missing keys cannot be recreated over encrypted broker data.
 * This uses the configured Host provider's protection, not an OS Secret Service guarantee.
 * The installer must dispose the accessor with its Host context and use assertActive for additional revocation.
 * @param options - Host service, stable partition and live encrypted-state observation.
 * @returns A disposable Host-only accessor; each successful request owns a separate key buffer.
 */
export declare function createHostManagementSecret(options: HostManagementSecretOptions): HostManagementSecret;
//# sourceMappingURL=host-management-secret.d.ts.map