/** Private Host orchestration from a real creation approval to verified device publication. */
import type { Context } from '@deepseek-ai/cordis';
import type { IdentityReference } from '@agent-network-protocol/anp-identity';
import type AnpIdentityService from './index.js';
import type { IdentityManagement } from './management-types.js';
import { z } from 'zod';
export declare const RegistrationBootstrapConfigSchema: z.ZodObject<{
    id: z.ZodString;
    requestId: z.ZodString;
    stateRoot: z.ZodString;
    origin: z.ZodString;
    email: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    clientName: z.ZodString;
    capabilities: z.ZodDefault<z.ZodObject<{
        mcpMachine: z.ZodBoolean;
        papSession: z.ZodBoolean;
        papAccount: z.ZodBoolean;
    }, z.core.$strict>>;
    redirectUris: z.ZodDefault<z.ZodArray<z.ZodString>>;
    managementAudience: z.ZodDefault<z.ZodString>;
    pollIntervalMs: z.ZodDefault<z.ZodNumber>;
    providerReadyTimeoutMs: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export type RegistrationBootstrapConfig = z.infer<typeof RegistrationBootstrapConfigSchema>;
export type RegistrationBootstrapInput = z.input<typeof RegistrationBootstrapConfigSchema>;
export type RegistrationBootstrapPhase = 'awaiting_approval' | 'awaiting_email_verification' | 'registering' | 'publishing' | 'published' | 'registration_uncertain' | 'blocked' | 'disposed';
export type RegistrationBootstrapReason = 'approval_unavailable' | 'approval_denied' | 'invalid_configuration' | 'credential_unavailable' | 'email_unavailable' | 'provider_unavailable' | 'publication_failed' | 'client_upgrade_required';
/** Safe manager/UI projection; no factor, credential, key or remote response is returned. */
export interface RegistrationBootstrapStatus {
    id: string;
    requestId: string;
    phase: RegistrationBootstrapPhase;
    reason?: RegistrationBootstrapReason;
    reference?: IdentityReference;
    clientId?: string;
}
export interface RegistrationBootstrapController {
    status(): RegistrationBootstrapStatus;
    dispose(): Promise<void>;
}
/** Install the configured manager-owned flow. Its caller supplies the actual management facade and Context.
 * @param options - Non-secret configuration, actual Host management authority and optional HTTP transport.
 * @returns A safe status projection and quiescent disposer.
 */
export declare function startRegistrationBootstrap(options: {
    context: Context;
    service: AnpIdentityService;
    manager: IdentityManagement;
    config: RegistrationBootstrapConfig;
    fetch?: typeof fetch;
}): RegistrationBootstrapController;
//# sourceMappingURL=registration-bootstrap.d.ts.map