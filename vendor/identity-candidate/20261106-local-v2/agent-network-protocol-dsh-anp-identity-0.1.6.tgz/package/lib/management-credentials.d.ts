import type { IdentityReference } from '@agent-network-protocol/anp-identity';
import type { ManagementCredentialBroker, DeviceManagementCredential } from './management-driver.js';
/** Each key resolver invocation must return a fresh, owner-controlled 32-byte encryption key. */
export declare class EncryptedManagementCredentialBroker implements ManagementCredentialBroker {
    private readonly root;
    private readonly encryptionKey;
    constructor(root: string, encryptionKey: () => Promise<Buffer>);
    private partition;
    get(reference: IdentityReference, origin: string): Promise<DeviceManagementCredential | undefined>;
    private writeUnlocked;
    set(reference: IdentityReference, origin: string, credential: DeviceManagementCredential): Promise<void>;
    reserveOperation(reference: IdentityReference, origin: string, operationId: string, body: Record<string, unknown>): Promise<Record<string, unknown>>;
    private transaction;
}
//# sourceMappingURL=management-credentials.d.ts.map