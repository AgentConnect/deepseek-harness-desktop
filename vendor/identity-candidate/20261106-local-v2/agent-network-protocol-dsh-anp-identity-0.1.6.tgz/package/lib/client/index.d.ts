import type { Context as ClientContext } from "@deepseek-ai/cordis";
import { IdentityController } from "./controller.js";
import { IdentityOverlay, IdentitySettings } from "./views.js";
export declare const inject: string[];
export declare function apply(ctx: ClientContext): Promise<() => Promise<void>>;
export { IdentityController, IdentitySettings, IdentityOverlay };
//# sourceMappingURL=index.d.ts.map