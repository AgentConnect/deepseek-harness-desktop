import { type ReactNode } from "react";
import { IdentityController } from "./controller.js";
export declare const FULL_PERMISSION_NOTICE = "\u5F53\u524D\u9ED8\u8BA4\u6388\u4E88\u8BE5\u8EAB\u4EFD\u7684\u5168\u90E8\u4F7F\u7528\u6743\u9650\uFF0C\u6682\u4E0D\u652F\u6301\u9010\u9879\u9009\u62E9\u3002";
/** Actual settings-section contribution, not a stand-alone preview. */
export declare function IdentitySettings({ controller, }: {
    controller: IdentityController;
}): ReactNode;
export declare function IdentityOverlay({ controller, }: {
    controller: IdentityController;
}): ReactNode;
//# sourceMappingURL=views.d.ts.map