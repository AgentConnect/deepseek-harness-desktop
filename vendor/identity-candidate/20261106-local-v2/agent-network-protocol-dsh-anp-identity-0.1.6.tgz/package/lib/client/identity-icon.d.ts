/** Decorative contact-card glyph for the settings navigation entry. */
export declare function IdentityIcon(): import("react").JSX.Element;
//# sourceMappingURL=identity-icon.d.ts.map