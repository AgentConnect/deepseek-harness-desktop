import type { OAuthClientIdentity } from "../publication-types.js";
import type { RemoteResult } from "@deepseek-ai/dsh-typert-protocol";
import type { IdentityReference } from "@agent-network-protocol/anp-identity";
import type { AuthorizationDecision, AuthorizationGrant, AuthorizationRequest } from "../authorization-types.js";
import type { IdentityManagement, ManagedIdentitySummary, RequestReview } from "../management-types.js";
export type ManagementRemote = {
    [K in keyof IdentityManagement]: (...args: Parameters<IdentityManagement[K]>) => Promise<RemoteResult<Awaited<ReturnType<IdentityManagement[K]>> | null>>;
};
export type ManagerModal = {
    readonly kind: "request";
    readonly review: RequestReview;
} | {
    readonly kind: "result";
    readonly review: RequestReview;
} | {
    readonly kind: "permissions" | "revoke";
    readonly grant: AuthorizationGrant;
    readonly identity: ManagedIdentitySummary;
} | {
    readonly kind: "delete";
    readonly identity: ManagedIdentitySummary;
};
export interface ManagerView {
    readonly loading: boolean;
    readonly identities: readonly ManagedIdentitySummary[];
    readonly requests: readonly AuthorizationRequest[];
    readonly history: readonly AuthorizationRequest[];
    readonly selectedKey: string | null;
    readonly grants: readonly AuthorizationGrant[];
    readonly publication: OAuthClientIdentity | null;
    readonly document: string | null;
    readonly documentOpen: boolean;
    readonly modal: ManagerModal | null;
    readonly pending: boolean;
    readonly error: string | null;
    readonly notice: string | null;
}
export declare const identityKey: (ref: IdentityReference) => string;
export declare const identityReference: (identity: ManagedIdentitySummary) => IdentityReference;
/** One shared controller owns both settings and overlay; remounts cannot duplicate prompts. */
export declare class IdentityController {
    private readonly remote;
    private view;
    private listeners;
    private timer;
    private refreshing;
    private disposed;
    private pauseQueue;
    private selectionVersion;
    private returnFocus;
    getSnapshot: () => ManagerView;
    subscribe: (listener: () => void) => (() => void);
    constructor(remote: ManagementRemote);
    private patch;
    private call;
    start(): void;
    dispose(): void;
    refresh(): Promise<void>;
    selectIdentity(key: string): Promise<void>;
    selected(): ManagedIdentitySummary | undefined;
    private loadGrants;
    private captureFocus;
    openRequest(id: string, automatic?: boolean): Promise<void>;
    closeModal(later?: boolean): void;
    decide(decision: Omit<AuthorizationDecision, "requestId" | "expectedVersion">): Promise<void>;
    openPermissions(grantId: string): Promise<void>;
    openRevoke(grantId: string): Promise<void>;
    private openGrantModal;
    revoke(): Promise<void>;
    openDelete(): void;
    deleteIdentity(confirmationName: string): Promise<void>;
    retryPublication(): Promise<void>;
    toggleDocument(): Promise<void>;
    loadHistory(): Promise<void>;
    openResult(requestId: string): Promise<void>;
    reauthorize(request: AuthorizationRequest): Promise<void>;
    copy(value: string): Promise<void>;
    private fail;
    private action;
}
//# sourceMappingURL=controller.d.ts.map