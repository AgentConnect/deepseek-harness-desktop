declare module "@deepseek-ai/dsh-client-ui-slots" {
    interface SlotMap {
        "settings.nav.icon": {
            kind: "list";
            scope: "root";
            owner: {
                children?: never;
            };
        };
    }
}
export {};
//# sourceMappingURL=settings-icon-slot.d.ts.map