import type { JsonValue, PublicIdentity } from '@agent-network-protocol/anp-identity';
import type { ProviderLease } from '@agent-network-protocol/anp-identity/provider';
/** Refresh only the proof of the exact, still-unpublished local E1 creation snapshot.
 * @param native - The manager's short-lived, provider-bound native lease.
 * @param identity - The local snapshot selected by the existing registration flow.
 * @param origin - The fixed registration service origin.
 * @returns The signed document and a final local snapshot fence for the physical send.
 */
export declare function prepareInitialRegistrationProof(native: ProviderLease, identity: PublicIdentity, origin: string): Promise<{
    document: JsonValue;
    assertCurrent(native: ProviderLease): Promise<void>;
}>;
//# sourceMappingURL=initial-registration-proof.d.ts.map