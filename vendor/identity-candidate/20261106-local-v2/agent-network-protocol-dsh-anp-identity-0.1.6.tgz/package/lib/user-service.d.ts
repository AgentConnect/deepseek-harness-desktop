import type { PublicationCoordinator } from './publication.js';
import type { Context } from '@deepseek-ai/cordis';
import type { ProviderLease } from '@agent-network-protocol/anp-identity/provider';
import type { IdentityReference, PublicIdentity } from './types.js';
import { AuthorizationEngine } from './authorization.js';
import type { CapabilitySnapshot, CreateParameters, CreateResult, VerifiedCaller } from './authorization-types.js';
import type { UserIdentityClient } from './user-client.js';
export interface UserServiceHost {
    ensureReady(): Promise<void>;
    resolveCaller(context: Context): VerifiedCaller;
    validateCaller(caller: VerifiedCaller): Promise<void>;
    resolveSnapshot(caller: VerifiedCaller, identity: IdentityReference): Promise<CapabilitySnapshot>;
    createIdentity(operationId: string, caller: VerifiedCaller, parameters: CreateParameters): Promise<CreateResult>;
    reconcileCreation(operationId: string, caller: VerifiedCaller, parameters: CreateParameters): Promise<CreateResult | undefined>;
    withNative<T>(operation: (lease: ProviderLease) => Promise<T>): Promise<T>;
}
/** Host boundary. The engine is never exposed on the ordinary client or management Remote. */
export declare class UserIdentityService {
    readonly host: UserServiceHost;
    readonly publications?: PublicationCoordinator | undefined;
    readonly engine: AuthorizationEngine;
    readonly ready: Promise<void>;
    constructor(stateRoot: string, host: UserServiceHost, publications?: PublicationCoordinator | undefined);
    bind(context: Context): UserIdentityClient;
    private managed;
}
export declare function requestSigningKid(identity: PublicIdentity): string;
//# sourceMappingURL=user-service.d.ts.map