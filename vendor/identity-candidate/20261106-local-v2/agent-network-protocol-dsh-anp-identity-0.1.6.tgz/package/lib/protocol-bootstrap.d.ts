/** Optional installed consumer that requests user approval before creating a protocol identity. */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const PROTOCOL_BOOTSTRAP_CONSUMER = "@agent-network-protocol/dsh-anp-identity/protocol-bootstrap";
export declare const name = "anp-identity-protocol-bootstrap";
export declare const inject: string[];
export interface Config {
    requestId: string;
    profile: 'e1' | 'web';
    label: string;
    domain: string;
    path: string;
    /** Canonical full Handle shown in the creation approval. */
    handle: string;
    providerReadyTimeoutMs: number;
}
export declare const Config: z<Config>;
/** Submit one stable request from this actual installed Context; this never approves or registers it.
 * @param context - Loader-installed ordinary consumer.
 * @param config - Non-secret local creation request and bounded provider startup wait.
 */
export declare function apply(context: Context, config: Config): Promise<void>;
//# sourceMappingURL=protocol-bootstrap.d.ts.map