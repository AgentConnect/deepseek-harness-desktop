import type { PublicationConfig } from './publication-types.js';
/** Optional Host manager boundary. Never expose this service to consumer leases. */
import type { Context } from "@deepseek-ai/cordis";
import { TypertRemoteService } from "@deepseek-ai/dsh-typert-protocol";
import type { IdentityReference } from "@agent-network-protocol/anp-identity";
import type { AuthorizationDecision } from "./authorization-types.js";
import type { RequestVersion, RevokeGrantInput, DeleteManagedIdentityInput } from "./management-types.js";
export declare class IdentityManagerRemote extends TypertRemoteService {
    static inject: string[];
    private readonly manager;
    constructor(ctx: Context);
    listIdentities(): Promise<import("./management-types.js").ManagedIdentitySummary[]>;
    listRequests(input?: boolean): Promise<import("./authorization-types.js").AuthorizationRequest[]>;
    getRequest(input: string): Promise<import("./management-types.js").RequestReview>;
    decide(input: AuthorizationDecision): Promise<import("./authorization-types.js").AuthorizationRequest>;
    grants(input: IdentityReference): Promise<import("./authorization-types.js").AuthorizationGrant[]>;
    revoke(input: RevokeGrantInput): Promise<null>;
    retryPublication(input: IdentityReference): Promise<import("./publication-types.js").OAuthClientIdentity>;
    publicationStatus(input: IdentityReference): Promise<import("./publication-types.js").OAuthClientIdentity>;
    publishIdentity(input: {
        reference: IdentityReference;
        config: PublicationConfig;
    }): Promise<import("./publication-types.js").OAuthClientIdentity>;
    publicDocument(input: IdentityReference): Promise<unknown>;
    deleteIdentity(input: DeleteManagedIdentityInput): Promise<null>;
    markPrompted(input: RequestVersion): Promise<null>;
    reauthorize(input: RequestVersion): Promise<import("./authorization-types.js").AuthorizationRequest>;
}
export default IdentityManagerRemote;
//# sourceMappingURL=management-remote.d.ts.map