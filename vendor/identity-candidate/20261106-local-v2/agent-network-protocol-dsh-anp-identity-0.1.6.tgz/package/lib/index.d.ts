import type { PapCallbackManagementOperations } from './pap-callback.js';
import { type ManagementCredentialBroker, type LocalRegistrationInput } from './management-driver.js';
import type { ProtocolUsePolicy, ProtocolIdentityClient, PapHostConsumer } from './protocol-client.js';
import type { PublicationBackend } from './publication-types.js';
import { Service, type Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { IdentityReference } from '@agent-network-protocol/anp-identity';
import type { UserIdentityClient } from './user-client.js';
import type { IdentityManagement } from './management-types.js';
import { type AnpIdentityService as AnpIdentityServiceContract, type HostProviderLease, type ProviderRequest } from './provider-api.js';
import type { AnpIdentityHealth, ClientRequest, IdentityClientLease } from './types.js';
export type * from './types.js';
export { AnpIdentityPluginError } from './errors.js';
export type { AnpIdentityPluginErrorCode } from './errors.js';
export { ANP_IDENTITY_HTTP_MAX_BODY_BYTES, } from './http-auth.js';
export { ANP_IDENTITY_PROVIDER_PROTOCOL, ANP_IDENTITY_SERVICE_PROTOCOL, } from './provider-api.js';
export type { AnpIdentityService as AnpIdentityServiceContract, HostProviderLease, ProviderRequest, } from './provider-api.js';
declare module '@deepseek-ai/cordis' {
    interface Context {
        anpIdentity: AnpIdentityServiceContract;
    }
}
export interface Config {
    readonly signerMode?: 'local';
    /** Absolute ANP Identity Store root. Defaults below DSH_HOME. */
    readonly stateRoot?: string;
    /** Exact same-process consumer names permitted to acquire leases. */
    readonly allowConsumers?: string[];
    /** Narrow Host-only consumers permitted to acquire Provider leases. */
    readonly allowProviderConsumers?: string[];
    /** Exact HTTPS origins permitted per consumer for authenticated HTTP. */
    readonly httpAllowedOrigins?: Record<string, string[]>;
    /** Run native Store recovery when a Provider opens. */
    readonly recoveryOnOpen?: boolean;
    /** Installed plugin identifiers requiring explicit user decisions instead of legacy access. */
    readonly oauthAllowedAudiences?: Record<string, string[]>;
    readonly userConsumers?: string[];
    readonly protocolPolicies?: ProtocolUsePolicy[];
}
export declare const Config: z<Config>;
/** One multi-DID ANP Identity service with a replaceable native Provider. */
export declare class AnpIdentityService extends Service implements AnpIdentityServiceContract {
    static Config: z<Config>;
    private readonly resolvedConfig;
    private readonly catalogStore;
    private providerSlot;
    private readonly publications;
    private readonly publicationBackends;
    private readonly papCallbackAuthorities;
    private readonly protocols;
    private readonly users;
    private readonly hostContext;
    private readonly disabledFences;
    private readonly lifecycleWrites;
    constructor(ctx: Context, config: Config);
    health(): Promise<AnpIdentityHealth>;
    private registerProvider;
    acquireClient(input: ClientRequest): Promise<IdentityClientLease>;
    acquireProvider(input: ProviderRequest): HostProviderLease;
    private listForClient;
    private createForClient;
    private getForClient;
    private deleteForClient;
    private recoverForClient;
    private setHandleForClient;
    private assertManagedAccess;
    private assertHostTransitionAccess;
    private grantConsumer;
    private revokeConsumer;
    private createForHost;
    private deleteForHost;
    private createNativeWithRecovery;
    private removeLease;
    private initializeSlot;
    private reconcile;
    private resolveAuthorized;
    private loadCatalog;
    private assertAllowedConsumer;
    private requireSlot;
    private assertSlot;
    private awaitProvider;
    /** Host-bound ordinary facade; request inputs never select a caller. */
    bindUserConsumer(context: Context): UserIdentityClient;
    bindProtocolConsumer(context: Context): ProtocolIdentityClient;
    /** Bind the actual installed PAP Host. Private callback access additionally requires its current opaque target.
     * @param context - Original Loader-installed PAP plugin Context.
     * @returns Public identity selection and target-bound, closed callback operations.
     */
    bindPapHostConsumer(context: Context): PapHostConsumer;
    /** Install a real device-authorized backend; the document id comes from authenticated resolve. */
    configureManagedPublicationBackend(context: Context, name: string, input: {
        reference: IdentityReference;
        origin: string;
        credentials: ManagementCredentialBroker;
        fetch?: typeof fetch;
    }): Promise<{
        backend: string;
        documentId: string;
        callbackManagement: PapCallbackManagementOperations;
        dispose: () => void;
    }>;
    /** Register the public local Manifest through User Service and persist its verified management credential. */
    registerLocalIdentity(context: Context, input: {
        reference: IdentityReference;
        origin: string;
        credentials: ManagementCredentialBroker;
        registration: LocalRegistrationInput;
        managementAudience?: string;
        handleDomain?: string;
        fetch?: typeof fetch;
        /** Optional tighter Host lifecycle fence, never a source of management authority. */
        assertActive?: () => void;
    }): Promise<{
        did: string;
        deviceId: string;
        state: 'registered';
    }>;
    /** Pin the actual ready provider for an approved local identity and the original manager Context.
     * @param context - Original root-installed manager Context.
     * @param reference - Local identity whose current provider is being pinned.
     * @param additionalCheck - Optional stricter Host lifecycle check.
     * @returns A synchronous fence that never switches to a replacement provider.
     */
    pinManagementContext(context: Context, reference: IdentityReference, additionalCheck?: () => void): Promise<() => void>;
    /** Host-only manager; the ordinary consumer facade never exposes this object. */
    registerPublicationBackend(context: Context, name: string, backend: PublicationBackend): () => void;
    private assertManagementContext;
    acquireManagement(context?: Context, additionalCheck?: () => void): IdentityManagement;
    private assertNoHostAssociations;
    private managementIdentities;
    private installedEntries;
    private resolveInstalledCaller;
    private assertInstalledCaller;
    private cancelDisabledRequests;
    private assertLegacyConsumer;
    private assertLegacyCallerContext;
    private withUserNative;
    private withProtocolNative;
    private withPublicationNative;
    private userSnapshot;
    private createConfirmed;
    private reconcileConfirmed;
    private recoverConfirmedIntent;
    private assertNoUnresolvedUserCreate;
    private disposeSlot;
}
export default AnpIdentityService;
export { createPublicationBackend } from './publication-http.js';
export type { PublicationConfig, PublicationBackend, OAuthClientIdentity } from './publication-types.js';
export { EncryptedManagementCredentialBroker } from './management-credentials.js';
export { createManagedPublicationDriver, registerLocalIdentity } from './management-driver.js';
export type { ManagementCredentialBroker, DeviceManagementCredential, LocalRegistrationInput } from './management-driver.js';
export type { PapHostConsumer } from './protocol-client.js';
export { PapCallbackManagementError } from './pap-callback.js';
export type { PapCallbackRegistration, PapCallbackClaim, PapCallbackRegistrationResult, PapCallbackClaimResult, PapCallbackRegisterOperation, PapCallbackClaimOperation, PapCallbackManagementOperations, PapCallbackManagementErrorCode } from './pap-callback.js';
//# sourceMappingURL=index.d.ts.map