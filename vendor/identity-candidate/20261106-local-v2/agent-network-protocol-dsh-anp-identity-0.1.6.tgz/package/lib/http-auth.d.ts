import type { IdentityReference } from '@agent-network-protocol/anp-identity';
import type { ProviderLease } from '@agent-network-protocol/anp-identity/provider';
import type { AuthenticatedHttp } from './types.js';
export declare const ANP_IDENTITY_HTTP_MAX_BODY_BYTES: number;
export declare function createAuthenticatedHttp(reference: IdentityReference, lease: ProviderLease, allowedOrigins: ReadonlySet<string>, assertActive: () => Promise<void>, requestSigningKid: () => Promise<string>): AuthenticatedHttp;
//# sourceMappingURL=http-auth.d.ts.map