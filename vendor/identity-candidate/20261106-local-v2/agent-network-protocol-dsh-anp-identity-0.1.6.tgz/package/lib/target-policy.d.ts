/** Context-bound protocol authorization with opaque target, scope and temporary-key references. */
import type { Context } from '@deepseek-ai/cordis';
import type { ProviderLease } from '@agent-network-protocol/anp-identity/provider';
import type { VerifiedCaller } from './authorization-types.js';
import type { PublicationCoordinator } from './publication.js';
import type { ProtocolUsePolicy, ProtocolIdentityClient } from './protocol-client.js';
export interface ProtocolAuthorityHost {
    resolveCaller(context: Context): VerifiedCaller;
    assertCaller(caller: VerifiedCaller): void;
    providerGeneration(): unknown;
    withNative<T>(operation: (native: ProviderLease) => Promise<T>): Promise<T>;
}
/** The trusted adapter validates public discovery; this authority enforces identity and permission policy. */
export declare class ProtocolIdentityAuthority {
    private readonly policies;
    private readonly host;
    private readonly publications;
    constructor(policies: readonly ProtocolUsePolicy[], host: ProtocolAuthorityHost, publications: PublicationCoordinator);
    bind(context: Context): ProtocolIdentityClient;
    private validateEvidence;
    private validateRequest;
}
//# sourceMappingURL=target-policy.d.ts.map