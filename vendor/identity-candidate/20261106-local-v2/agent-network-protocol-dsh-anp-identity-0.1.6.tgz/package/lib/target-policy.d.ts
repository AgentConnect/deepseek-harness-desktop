/** Context-bound protocol authorization with opaque target, scope and temporary-key references. */
import type { Context } from '@deepseek-ai/cordis';
import type { IdentityReference } from '@agent-network-protocol/anp-identity';
import type { ProviderLease } from '@agent-network-protocol/anp-identity/provider';
import type { VerifiedCaller } from './authorization-types.js';
import type { PublicationCoordinator } from './publication.js';
import type { ProtocolUsePolicy, ProtocolIdentityClient, PapHostConsumer } from './protocol-client.js';
import type { PapCallbackManagementOperations } from './pap-callback.js';
export interface ProtocolAuthorityHost {
    resolveCaller(context: Context): VerifiedCaller;
    assertCaller(caller: VerifiedCaller): void;
    providerGeneration(): unknown;
    withNative<T>(operation: (native: ProviderLease) => Promise<T>): Promise<T>;
}
/** Private manager-owned driver and encrypted public transaction bindings. No credential value is returned. */
export interface PapCallbackHostAuthority {
    assertActive(): Promise<void>;
    operations: PapCallbackManagementOperations;
    reserve(transactionId: string, binding: Record<string, unknown>): Promise<Record<string, unknown>>;
    read(transactionId: string): Promise<Record<string, unknown> | undefined>;
}
/** The trusted adapter validates public discovery; this authority enforces identity and permission policy. */
export declare class ProtocolIdentityAuthority {
    private readonly policies;
    private readonly host;
    private readonly publications;
    private readonly targets;
    constructor(policies: readonly ProtocolUsePolicy[], host: ProtocolAuthorityHost, publications: PublicationCoordinator);
    bind(context: Context): ProtocolIdentityClient;
    /** Bind the exact installed PAP plugin; publication and callback data never replace its Host policy. */
    bindPapHost(context: Context, callbackAuthority: (identity: IdentityReference, backend: string) => Promise<PapCallbackHostAuthority>): PapHostConsumer;
    private validateEvidence;
    private validateRequest;
}
//# sourceMappingURL=target-policy.d.ts.map