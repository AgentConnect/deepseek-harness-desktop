/** Stable DSH plugin error without identity, path, payload, or provider detail. */
export declare class AnpIdentityPluginError extends Error {
    readonly code: AnpIdentityPluginErrorCode;
    readonly name = "AnpIdentityPluginError";
    constructor(code: AnpIdentityPluginErrorCode, message?: string);
}
export type AnpIdentityPluginErrorCode = 'invalid_request' | 'provider_unavailable' | 'provider_incompatible' | 'provider_disposed' | 'consumer_forbidden' | 'capability_forbidden' | 'identity_not_found' | 'identity_unclaimed' | 'identity_deleting' | 'identity_in_use' | 'handle_conflict' | 'catalog_conflict' | 'catalog_corrupt' | 'http_origin_forbidden' | 'http_body_too_large' | 'http_body_unsupported';
export declare function pluginError(code: AnpIdentityPluginErrorCode): AnpIdentityPluginError;
//# sourceMappingURL=errors.d.ts.map