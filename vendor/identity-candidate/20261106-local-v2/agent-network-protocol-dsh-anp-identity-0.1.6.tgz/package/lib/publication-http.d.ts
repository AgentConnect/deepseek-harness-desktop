/** User Service transport. The Host supplies its existing authenticated management channel. */
import type { PublicationBackend, PublicationCapabilities } from './publication-types.js';
export declare function exactHttps(value: string, requirePath?: boolean): string;
/** Validate a declared callback without changing its bytes. HTTP is restricted to V2 PAP account loopback.
 * @param value - Exact configured callback URI.
 * @param capabilities - V2 capabilities; omission preserves the HTTPS-only V1 rule.
 * @returns The unchanged configured URI.
 */
export declare function publicationRedirectUri(value: string, capabilities?: PublicationCapabilities): string;
export declare function createPublicationBackend(input: {
    origin: string;
    /** Credentials stay inside this Host function; outgoing redirects must not be followed. */
    authenticatedFetch(request: Request): Promise<Response>;
    publicFetch?: (request: Request) => Promise<Response>;
    publishDocument: PublicationBackend['publishDocument'];
}): PublicationBackend;
/** Reject duplicate JSON members, including escaped aliases, before using metadata. */
export declare function parsePublicJson(text: string): unknown;
//# sourceMappingURL=publication-http.d.ts.map