/** Flush POSIX directory metadata after an already-fsynced atomic file replacement.
 * Node cannot open or fsync a directory on Windows. File fsync and atomic rename
 * remain mandatory there; do not swallow file-write or rename failures.
 */
export declare function syncDirectory(path: string, platform?: NodeJS.Platform): Promise<void>;
//# sourceMappingURL=sync-directory.d.ts.map