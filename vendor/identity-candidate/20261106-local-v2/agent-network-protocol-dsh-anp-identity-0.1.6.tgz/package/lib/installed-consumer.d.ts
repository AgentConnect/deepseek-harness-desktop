import type { Context } from '@deepseek-ai/cordis';
/** Installed metadata supplied by the Host Loader, never by a consumer request. */
export interface InstalledConsumerEntry {
    readonly options: {
        readonly name: string;
    };
    readonly disabled?: boolean;
    readonly fiber?: {
        readonly state: number;
        readonly ctx?: Context;
    };
}
/**
 * Enumerate ordinary consumers, including Loader trees mounted outside its root
 * entry walk. Cordis owns the runtime/fiber registry; Loader owns entry metadata,
 * its containing store and the exact currently installed fiber. All must agree.
 *
 * This does not broaden the separate root-only management/Provider admission.
 * Direct ctx.plugin() calls, inherited parent entries and names on plugin exports
 * do not establish an installed identity.
 */
export declare function installedConsumerEntries(host: Context): InstalledConsumerEntry[];
/** Resolve only the exact active installed fiber in this Host's runtime. */
export declare function resolveInstalledConsumer(host: Context, caller: Context): InstalledConsumerEntry | undefined;
//# sourceMappingURL=installed-consumer.d.ts.map