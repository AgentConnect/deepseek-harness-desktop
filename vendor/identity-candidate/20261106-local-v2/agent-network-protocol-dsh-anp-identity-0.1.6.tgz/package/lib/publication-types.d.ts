/** Public material state only. Credentials and assertions never enter the catalog. */
import { z } from 'zod';
import type { IdentityReference, OAuthPublicJwk } from '@agent-network-protocol/anp-identity';
import type { ProviderDocumentChangeSession } from '@agent-network-protocol/anp-identity/provider';
export declare const EcPublicJwkSchema: z.ZodObject<{
    kty: z.ZodLiteral<"EC">;
    crv: z.ZodLiteral<"P-256">;
    x: z.ZodString;
    y: z.ZodString;
    kid: z.ZodString;
    alg: z.ZodLiteral<"ES256">;
    use: z.ZodLiteral<"sig">;
}, z.core.$strict>;
export declare const PublicJwkSchema: z.ZodUnion<readonly [z.ZodObject<{
    kty: z.ZodLiteral<"OKP">;
    crv: z.ZodLiteral<"Ed25519">;
    x: z.ZodString;
    kid: z.ZodString;
    alg: z.ZodLiteral<"EdDSA">;
    use: z.ZodLiteral<"sig">;
}, z.core.$strict>, z.ZodObject<{
    kty: z.ZodLiteral<"EC">;
    crv: z.ZodLiteral<"P-256">;
    x: z.ZodString;
    y: z.ZodString;
    kid: z.ZodString;
    alg: z.ZodLiteral<"ES256">;
    use: z.ZodLiteral<"sig">;
}, z.core.$strict>]>;
export type PublicationJwk = z.infer<typeof PublicJwkSchema>;
export declare const PublicationCapabilitiesSchema: z.ZodObject<{
    mcpMachine: z.ZodBoolean;
    papSession: z.ZodBoolean;
    papAccount: z.ZodBoolean;
}, z.core.$strict>;
export type PublicationCapabilities = z.infer<typeof PublicationCapabilitiesSchema>;
/** Derive the server profile from actual enabled capabilities. */
export declare function publicationProfile(v: PublicationCapabilities): string;
/** The management wire representation is exclusively snake_case. */
export interface PublicationIntentV2 {
    schema_version: 2;
    operation_id: string;
    expected_version: number;
    client_name: string;
    capabilities: {
        mcp_machine: boolean;
        pap_session: boolean;
        pap_account: boolean;
    };
    signing_keys: PublicationJwk[];
    active_kid: string;
    redirect_uris: string[];
}
export declare const PublicationConfigSchema: z.ZodObject<{
    backend: z.ZodString;
    documentId: z.ZodString;
    clientName: z.ZodString;
    redirectUris: z.ZodArray<z.ZodString>;
    capabilities: z.ZodOptional<z.ZodObject<{
        mcpMachine: z.ZodBoolean;
        papSession: z.ZodBoolean;
        papAccount: z.ZodBoolean;
    }, z.core.$strict>>;
    activeKid: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type PublicationConfig = z.infer<typeof PublicationConfigSchema>;
export declare const PublicationRecordSchema: z.ZodObject<{
    config: z.ZodObject<{
        backend: z.ZodString;
        documentId: z.ZodString;
        clientName: z.ZodString;
        redirectUris: z.ZodArray<z.ZodString>;
        capabilities: z.ZodOptional<z.ZodObject<{
            mcpMachine: z.ZodBoolean;
            papSession: z.ZodBoolean;
            papAccount: z.ZodBoolean;
        }, z.core.$strict>>;
        activeKid: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    operationId: z.ZodString;
    expectedVersion: z.ZodNumber;
    state: z.ZodEnum<{
        failed: "failed";
        awaiting_configuration: "awaiting_configuration";
        publishing: "publishing";
        published: "published";
    }>;
    clientId: z.ZodString;
    version: z.ZodNumber;
    key: z.ZodUnion<readonly [z.ZodObject<{
        kty: z.ZodLiteral<"OKP">;
        crv: z.ZodLiteral<"Ed25519">;
        x: z.ZodString;
        kid: z.ZodString;
        alg: z.ZodLiteral<"EdDSA">;
        use: z.ZodLiteral<"sig">;
    }, z.core.$strict>, z.ZodObject<{
        kty: z.ZodLiteral<"EC">;
        crv: z.ZodLiteral<"P-256">;
        x: z.ZodString;
        y: z.ZodString;
        kid: z.ZodString;
        alg: z.ZodLiteral<"ES256">;
        use: z.ZodLiteral<"sig">;
    }, z.core.$strict>]>;
    metadata: z.ZodOptional<z.ZodString>;
    jwks: z.ZodOptional<z.ZodString>;
    metadataSha256: z.ZodOptional<z.ZodString>;
    failure: z.ZodOptional<z.ZodEnum<{
        unavailable: "unavailable";
        publication_failed: "publication_failed";
        material_mismatch: "material_mismatch";
    }>>;
}, z.core.$strict>;
export type PublicationRecord = z.infer<typeof PublicationRecordSchema>;
export interface OAuthClientIdentity {
    readonly state: 'local' | 'awaiting_configuration' | 'publishing' | 'published' | 'failed';
    readonly did: string;
    readonly clientId?: string;
    readonly jwksUri?: string;
    readonly keyId?: string;
    readonly algorithm?: 'EdDSA' | 'ES256';
    readonly signerMode?: 'local';
    readonly capabilities?: PublicationCapabilities;
    readonly version?: number;
}
export interface PreparedClientMaterials {
    readonly schema_version?: 2;
    readonly profile?: string;
    readonly capabilities?: {
        mcp_machine: boolean;
        pap_session: boolean;
        pap_account: boolean;
    };
    readonly active_kid?: string;
    readonly key_set_digest?: string;
    readonly state: 'awaiting_configuration' | 'prepared' | 'published';
    readonly client_id: string;
    readonly version: number;
    readonly operation_id?: string;
    readonly metadata_sha256?: string;
    readonly metadata?: string;
    readonly jwks?: string;
}
/** Installed by a trusted Host, not consumer request input. */
export interface PublicationBackend {
    readonly origin: string;
    clientId(documentId: string): string;
    prepare(documentId: string, input: {
        operation_id: string;
        expected_version: number;
        client_name: string;
        key: OAuthPublicJwk;
        redirect_uris: string[];
    } | PublicationIntentV2): Promise<PreparedClientMaterials>;
    activate(documentId: string, operationId: string): Promise<PreparedClientMaterials>;
    readPublic(documentId: string, part: 'client.json' | 'jwks.json'): Promise<string>;
    /** Drive the existing authorized document-update/reconcile workflow. No unchecked document PUT. */
    publishDocument(reference: IdentityReference, session: ProviderDocumentChangeSession, assertActive: () => Promise<void>): Promise<void>;
}
//# sourceMappingURL=publication-types.d.ts.map