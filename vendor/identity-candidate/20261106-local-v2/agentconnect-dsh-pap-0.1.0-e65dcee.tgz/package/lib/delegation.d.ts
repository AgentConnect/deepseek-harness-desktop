import type { PapSigningLease } from './host.js';
import type { Delegation, KeyRef, PublicJwk, Subject } from './types.js';
export declare function thumbprint(jwk: PublicJwk): string;
export declare function verifyCompact(jwt: string, jwk: PublicJwk): boolean;
export declare function checkDelegation(jwt: string, key: KeyRef, clientId: string, identity: {
    alg: string;
    kid: string;
    publicJwk?: PublicJwk;
}, now: number): number;
export declare class DelegationAttemptFailure extends Error {
    readonly code: import('./errors.js').PapErrorCode;
    readonly key: KeyRef;
    readonly retired: boolean;
    constructor(code: import('./errors.js').PapErrorCode, key: KeyRef, retired: boolean);
}
export declare function newDelegation(subject: Subject, lease: PapSigningLease, generation: number, now: number, operationId: string): Promise<Delegation>;
