import type { HttpResponse, JsonObject, KeyScope, Subject } from './types.js';
export declare const id: (prefix: string) => string;
export declare const sha256: (value: string | Uint8Array) => string;
export declare const sha256Hex: (value: string | Uint8Array) => string;
export declare const scopeFor: (subject: Subject, accountSlot?: string) => KeyScope;
export declare function object(value: unknown): JsonObject;
export declare function strings(value: unknown): string[];
export declare function httpsUrl(value: unknown): URL;
export declare function htu(value: string): string;
export declare function parseJson(response: HttpResponse): JsonObject;
export declare function jwtParts(compact: string): {
    header: JsonObject;
    payload: JsonObject;
};
export declare function matchedRoute(template: string, actual: string): boolean;
/** Explicit PAP account callback lane; this exception never applies to public or resource URLs. */
export declare function isPapLoopbackRedirect(value: string): boolean;
