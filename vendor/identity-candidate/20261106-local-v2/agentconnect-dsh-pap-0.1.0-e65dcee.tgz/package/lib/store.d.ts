import type { HostSecretStore } from './host.js';
import type { PapState } from './types.js';
/** Encrypted, cross-process serialized transactions. The master key stays in Host secret storage. */
export declare class PapStore {
    readonly root: string;
    private readonly secrets;
    private readonly namespace;
    private readonly path;
    constructor(root: string, secrets: HostSecretStore, namespace: string);
    private key;
    transaction<T>(fn: (state: PapState) => T | Promise<T>): Promise<T>;
    read(): Promise<PapState>;
    recover(): Promise<void>;
}
