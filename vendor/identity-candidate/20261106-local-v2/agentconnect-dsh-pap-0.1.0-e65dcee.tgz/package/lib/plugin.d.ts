import { Service, type Context } from '@deepseek-ai/cordis';
import type { HttpTransport, IdentityRef } from './types.js';
import type { HostSecretStore } from './host.js';
import { type ProductResult } from './product-api.js';
export interface PapPluginConfig {
    /** Explicit opt-in; loading an unconfigured bundle performs no discovery or signing. */
    enabled?: boolean;
    stateRoot?: string;
    keyringService?: string;
    /** Approved C policy chosen by Host configuration, never by a Remote or model. */
    policyRef?: string;
    identityRef?: IdentityRef;
}
/** Optional OS-specific Host provider. It never supplies Agent keys or device credentials. */
export interface PapHostServices {
    secrets: HostSecretStore;
    transport?: HttpTransport;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        pap: PapService;
        papHost: PapHostServices;
    }
}
export declare const name = "@agentconnect/dsh-pap/plugin";
export declare const inject: string[];
/** Arbitrary provider/network descriptions never cross a public boundary. */
export declare function publicResult(operation: () => Promise<unknown>): Promise<ProductResult>;
/** Actual installed F Host. Engine, C targets and callback capabilities remain in this process. */
export declare class PapService extends Service {
    private readonly config;
    private readonly installedContext;
    private client?;
    private hostConsumer?;
    private selected?;
    private binding?;
    private stopped;
    private lastError?;
    private readonly ready;
    private readonly authHints;
    private readonly credentialHistory;
    private changing;
    constructor(ctx: Context, config?: PapPluginConfig);
    private assertInstalled;
    private consumer;
    private restore;
    private persistSelection;
    private select;
    private engine;
    private runPublic;
    private publicValue;
    private assertCurrentEngine;
    private catalog;
    start(): Promise<void>;
    stop(): void;
    getStatus(includeManagementHints?: boolean): Promise<object>;
    /** The installed user-only Typert manager receives the management facade. */
    acquireManagement(context: Context): {
        status(): Promise<ProductResult>;
        operations(): Promise<ProductResult>;
        execute(input: unknown): Promise<ProductResult>;
    };
    /** Agent capability contains only approved local operation references. */
    acquireTools(context: Context): {
        status(): Promise<ProductResult>;
        operations(): Promise<ProductResult>;
        request(input: unknown, signal?: AbortSignal): Promise<ProductResult>;
    };
    private manage;
}
export declare function apply(ctx: Context, config?: PapPluginConfig): PapService;
