import type { PapState } from './types.js';
export declare function ensureCredentialVault(state: PapState): NonNullable<PapState['credentialVault']>;
/** Called inside existing encrypted state transactions before replacing/clearing a credential. */
export declare function archiveCredentials(state: PapState, values: readonly (string | undefined)[]): void;
export interface CredentialObservation {
    accessToken: string;
    accessExpiresInMs?: number;
    refreshToken?: string;
}
/** Service-private redaction history. Live/unknown credentials are never evicted to fit a budget. */
export declare class CredentialHistory {
    private readonly clock;
    private readonly maxEntries;
    private readonly maxBytes;
    private readonly entries;
    private readonly active;
    private bytes;
    private blocked;
    private closed;
    constructor(clock?: () => number, maxEntries?: number, maxBytes?: number);
    private sweep;
    assertUsable(): void;
    restore(state: PapState): void;
    /** Never throws while an AS response is being persisted; a limit latches public output closed. */
    observe(input: CredentialObservation): void;
    /** Restored values have no trustworthy process-monotonic remaining lifetime. */
    rememberIfAbsent(secret: string): void;
    private remember;
    begin(): symbol;
    values(): string[];
    end(pin: symbol): void;
    dispose(): void;
}
