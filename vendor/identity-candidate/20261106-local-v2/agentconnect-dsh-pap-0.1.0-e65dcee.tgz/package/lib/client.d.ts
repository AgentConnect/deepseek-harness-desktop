import type { CredentialObservation } from './credential-history.js';
import type { PapHostOptions } from './host.js';
import { PapStore } from './store.js';
import type { Company, Grant, HttpResponse, HttpTransport, Operation, PapState } from './types.js';
/** Same-process permission fence, never a wire input. */
export interface PapDispatchControl {
    signal?: AbortSignal;
    assertAllowed?: (state: PapState) => void;
    /** Host-only in-memory response redaction set; never register this callback on a wire surface. */
    captureSecrets?: (values: readonly string[], credentials?: CredentialObservation) => void;
}
/** Host-only engine. UI receives safe summaries, never this object or signer capabilities. */
export declare class PapClient {
    private readonly options;
    private readonly transport;
    readonly store: PapStore;
    private readonly discovery;
    private readonly clock;
    private closed;
    private readonly discoveryFlights;
    private readonly recentJtis;
    private readonly cooldownWaiters;
    private readonly refreshFlights;
    private readonly abortedSessions;
    constructor(options: PapHostOptions, transport: HttpTransport);
    close(): void;
    recover(): Promise<void>;
    resolvePapCompany(domain: string): Promise<{
        companyRef: string;
        companyId: string;
        name: string;
        authMode: Company['authMode'];
        scopes: string[];
    }>;
    getOrCreatePapUser(companyRef: string, mode?: 'regular' | 'anonymous', agent?: boolean): Promise<{
        subjectRef: string;
    }>;
    openPapSession(subjectRef: string, accountSlot?: string): Promise<{
        sessionRef: string;
    }>;
    private company;
    private subject;
    private sameUser;
    private assertAccountEpoch;
    private session;
    private ensureCompanyFresh;
    private lease;
    private assertWaitActive;
    private awaitCooldown;
    rotateDelegation(subjectRef: string): Promise<void>;
    private delegation;
    private cleanupRetirements;
    dispatchPap(sessionRef: string, operation: Operation, control?: PapDispatchControl): Promise<HttpResponse>;
    private checkSessionJwt;
    private saveNonce;
    startSignIn(subjectRef: string, input: {
        scopes: string[];
        resource: string;
        redirectUri: string;
        callbackMode: 'handoff' | 'loopback';
        method?: 'direct' | 'device';
    }): Promise<{
        transactionRef: string;
        authorizationUrl: string;
        accountSlot: string;
    }>;
    collectSignIn(transactionRef: string): Promise<{
        grantRef: string;
        accountSlot: string;
    }>;
    /** Called only by an authenticated Host callback listener or handoff, never an arbitrary model tool. */
    completeSignIn(transactionRef: string, response: {
        state?: string;
        iss?: string;
        code?: string;
        error?: string;
    }): Promise<{
        grantRef: string;
        accountSlot: string;
    }>;
    private parseGrant;
    private tokenRequest;
    refreshAccountGrant(grantRef: string, sessionRef?: string): Promise<void>;
    private waitForRefresh;
    private refresh;
    signOutAccount(subjectRef: string, accountSlot: string): Promise<{
        status: 'signed_out' | 'revocation_pending';
    }>;
    disconnectPap(sessionRef: string): Promise<void>;
    getPapStatus(): Promise<{
        companies: {
            companyRef: string;
            name: string;
            authMode: Company['authMode'];
        }[];
        sessions: {
            sessionRef: string;
            connected: boolean;
            account: boolean;
        }[];
        accounts: {
            grantRef: string;
            status: Grant['status'];
            scopes: string[];
        }[];
        supportedSignIn: ['direct'];
    }>;
}
