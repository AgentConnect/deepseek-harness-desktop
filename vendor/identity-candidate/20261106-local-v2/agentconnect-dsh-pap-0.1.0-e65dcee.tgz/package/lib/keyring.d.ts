import type { HostSecretStore } from './host.js';
/** Linux Secret Service adapter. No file fallback; a locked/missing keyring blocks credentials. */
export declare class KeyringSecretStore implements HostSecretStore {
    private readonly service;
    private readonly locksRoot;
    constructor(service: string, locksRoot: string);
    private command;
    getEncryptionKey(namespace: string): Promise<Uint8Array | undefined>;
    getOrCreateEncryptionKey(namespace: string): Promise<Uint8Array>;
}
