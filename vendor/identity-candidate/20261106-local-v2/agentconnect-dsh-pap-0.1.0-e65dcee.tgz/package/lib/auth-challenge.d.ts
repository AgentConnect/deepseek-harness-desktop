import type { PapAuthHint } from './errors.js';
import type { Company, HttpResponse } from './types.js';
interface Challenge {
    scheme: 'Bearer' | 'DPoP';
    error?: string;
    scope?: string;
    metadata?: string;
    invalid: boolean;
}
export declare function parseAuthenticate(value: string | undefined): {
    challenges: Challenge[];
    relevant: boolean;
};
export declare function protocolFailure(response: HttpResponse, company?: Company, resource?: string, preferred?: 'Bearer' | 'DPoP'): {
    code?: string;
    hint?: PapAuthHint;
    challenge: boolean;
};
export {};
