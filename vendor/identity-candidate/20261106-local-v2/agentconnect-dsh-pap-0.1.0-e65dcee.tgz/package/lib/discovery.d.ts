import type { Company, HttpTransport } from './types.js';
export declare class PapDiscovery {
    private readonly transport;
    private readonly clock;
    constructor(transport: HttpTransport, clock?: () => number);
    resolve(domain: string): Promise<Company>;
    private discover;
}
