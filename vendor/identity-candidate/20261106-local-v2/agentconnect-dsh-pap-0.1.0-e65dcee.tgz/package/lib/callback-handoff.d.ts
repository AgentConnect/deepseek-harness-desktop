import type { CallbackHandoff } from './host.js';
export interface CallbackRegistration {
    transaction_id: string;
    client_id: string;
    issuer: string;
    redirect_uri: string;
    state_sha256: string;
    claim_sha256: string;
    expires_at: string;
}
export interface CallbackClaim {
    transaction_id: string;
    claim_secret: string;
}
export interface CallbackRegistrationResult {
    transaction_id: string;
    callback_uri: string;
    expires_at: string;
}
export type CallbackClaimResult = {
    state: string;
    iss: string;
    code: string;
    error?: never;
} | {
    state: string;
    iss: string;
    error: string;
    code?: never;
};
export interface RegisterCallbackOperation {
    action: 'pap-callback-register';
    operationId: string;
    callback: CallbackRegistration;
}
export interface ClaimCallbackOperation {
    action: 'pap-callback-claim';
    operationId: string;
    callback: CallbackClaim;
}
export type CallbackManagementOperation = RegisterCallbackOperation | ClaimCallbackOperation;
export interface DeviceManagementOperations {
    /** The authenticated C Host driver supplies checkpoint/device proof and only the two fixed B routes. */
    execute(input: RegisterCallbackOperation): Promise<CallbackRegistrationResult>;
    execute(input: ClaimCallbackOperation): Promise<CallbackClaimResult>;
}
/** Fixed B callback relay, with an independent pickup secret. callbackRef is encrypted by PapStore. */
export declare class DeviceCallbackHandoff implements CallbackHandoff {
    private readonly management;
    constructor(management: DeviceManagementOperations);
    register(input: Parameters<CallbackHandoff['register']>[0]): Promise<{
        callbackRef: string;
    }>;
    collect(callbackRef: string): ReturnType<CallbackHandoff['collect']>;
}
