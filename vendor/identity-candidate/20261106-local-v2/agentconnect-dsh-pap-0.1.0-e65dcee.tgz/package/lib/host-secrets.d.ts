import { Service, type Context } from '@deepseek-ai/cordis';
import { KeyringSecretStore } from './keyring.js';
import type { PapHostServices } from './plugin.js';
export interface Config {
    keyringService: string;
    locksRoot: string;
}
export declare const name = "@agentconnect/dsh-pap/host-secrets";
/** Optional concrete Linux Host secrets provider. A callback driver can provide papHost instead. */
export declare class PapHostService extends Service implements PapHostServices {
    readonly secrets: KeyringSecretStore;
    constructor(ctx: Context, config: Config);
}
export declare function apply(ctx: Context, config: Config): PapHostService;
