/** Bounded RFC 8259 parser: fatal UTF-8 and duplicate object member rejection. */
export declare function strictJson(bytes: Uint8Array, maxBytes?: number): unknown;
