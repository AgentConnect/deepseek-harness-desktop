import type { Company, HttpResponse, Operation, PapState, ProductOperationApproval, Route } from './types.js';
import type { PapOperationRequest } from './product-api.js';
export declare function operationRef(company: Company, route: Route): string;
export declare function findOperation(state: PapState, reference: string): {
    company: Company;
    route: Route;
};
export declare function publicOperations(state: PapState, enabledOnly?: boolean): object[];
export declare function assertApproval(state: PapState, reference: string, expected: ProductOperationApproval): void;
export declare function prepareOperation(state: PapState, input: PapOperationRequest): {
    operation: Operation;
    approval: ProductOperationApproval;
};
export declare function privateValues(state: PapState, includeOAuthState?: boolean): string[];
export declare function sanitizePublicValue(value: unknown, secrets: readonly string[]): unknown;
export declare function publicResponse(response: HttpResponse, secrets?: readonly string[]): object;
