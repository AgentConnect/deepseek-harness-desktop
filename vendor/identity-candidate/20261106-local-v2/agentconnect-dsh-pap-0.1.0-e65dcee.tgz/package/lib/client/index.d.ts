import type { Context } from '@deepseek-ai/cordis';
import { PapSettingsController } from './controller.js';
import { PapSettings } from './views.js';
export declare const inject: string[];
export declare function apply(ctx: Context): Promise<() => Promise<void>>;
export { PapSettingsController, PapSettings };
