import { type ReactNode } from 'react';
import { PapSettingsController } from './controller.js';
export declare function PapSettings({ controller }: {
    controller: PapSettingsController;
}): ReactNode;
