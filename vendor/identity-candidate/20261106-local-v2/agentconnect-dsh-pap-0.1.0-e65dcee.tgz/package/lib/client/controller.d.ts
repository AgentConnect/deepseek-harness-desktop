import { z } from 'zod';
import type { PapManagementRequest } from '../product-api.js';
declare const reference: z.ZodObject<{
    storeId: z.ZodString;
    identityId: z.ZodString;
    did: z.ZodString;
}, z.core.$strip>;
declare const status: z.ZodObject<{
    state: z.ZodString;
    error: z.ZodOptional<z.ZodString>;
    identity: z.ZodOptional<z.ZodObject<{
        storeId: z.ZodString;
        identityId: z.ZodString;
        did: z.ZodString;
    }, z.core.$strip>>;
    companies: z.ZodDefault<z.ZodArray<z.ZodObject<{
        companyRef: z.ZodString;
        name: z.ZodString;
        authMode: z.ZodEnum<{
            no_as: "no_as";
            account: "account";
            disabled: "disabled";
        }>;
        scopes: z.ZodArray<z.ZodString>;
    }, z.core.$strip>>>;
    sessions: z.ZodDefault<z.ZodArray<z.ZodObject<{
        sessionRef: z.ZodString;
        companyRef: z.ZodOptional<z.ZodString>;
        connected: z.ZodBoolean;
        account: z.ZodBoolean;
        accountSlot: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>>;
    accounts: z.ZodDefault<z.ZodArray<z.ZodObject<{
        accountSlot: z.ZodString;
        companyRef: z.ZodOptional<z.ZodString>;
        status: z.ZodString;
        scopes: z.ZodArray<z.ZodString>;
        canRefresh: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strip>>>;
    pendingSignIns: z.ZodDefault<z.ZodArray<z.ZodObject<{
        transactionRef: z.ZodString;
        accountSlot: z.ZodString;
        companyRef: z.ZodOptional<z.ZodString>;
        expiresAt: z.ZodNumber;
    }, z.core.$strip>>>;
    authenticationHints: z.ZodDefault<z.ZodArray<z.ZodObject<{
        operationRef: z.ZodString;
        scheme: z.ZodEnum<{
            Bearer: "Bearer";
            DPoP: "DPoP";
        }>;
        scope: z.ZodOptional<z.ZodArray<z.ZodString>>;
        resourceMetadataUrl: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>>;
}, z.core.$strip>;
declare const operation: z.ZodObject<{
    operationRef: z.ZodString;
    companyRef: z.ZodString;
    method: z.ZodString;
    path: z.ZodString;
    enabled: z.ZodBoolean;
    account: z.ZodBoolean;
}, z.core.$strip>;
export interface UserPapRemote {
    status(): Promise<any>;
    operations(): Promise<any>;
    manage(input: PapManagementRequest): Promise<any>;
}
export interface PublicIdentityRemote {
    listIdentities(): Promise<any>;
    publicationStatus(identity: z.infer<typeof reference>): Promise<any>;
}
export interface SettingsView {
    status: z.infer<typeof status>;
    operations: z.infer<typeof operation>[];
    identities: {
        reference: z.infer<typeof reference>;
        label: string;
    }[];
    loading: boolean;
    pending: boolean;
    waitingIdentity: boolean;
    error: string | null;
    authorization: {
        transactionRef: string;
        url: string;
    } | null;
}
export declare const identityKey: (value: z.infer<typeof reference>) => string;
export declare class PapSettingsController {
    private readonly remotes;
    private view;
    private readonly listeners;
    private disposed;
    private refreshing;
    constructor(remotes: () => {
        pap?: UserPapRemote;
        identities?: PublicIdentityRemote;
    });
    getSnapshot: () => SettingsView;
    subscribe: (listener: () => void) => () => void;
    private patch;
    dispose(): void;
    refresh(): Promise<void>;
    execute(input: PapManagementRequest): Promise<void>;
}
export {};
