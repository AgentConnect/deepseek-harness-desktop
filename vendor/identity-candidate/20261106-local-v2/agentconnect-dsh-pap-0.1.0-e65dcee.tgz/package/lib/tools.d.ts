import type { Context } from '@deepseek-ai/cordis';
export declare const name = "@agentconnect/dsh-pap/tools";
export declare const inject: string[];
/** No tools for identity selection, discovery, browser sign-in, callback collection or sign-out. */
export declare function apply(ctx: Context): void;
