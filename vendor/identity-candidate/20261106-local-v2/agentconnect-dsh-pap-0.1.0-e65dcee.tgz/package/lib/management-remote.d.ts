import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { PapManagementRequest } from './product-api.js';
/** Mounted only on the authenticated user management Gateway, never an Agent tool. */
export default class PapManagerRemote extends TypertRemoteService {
    static inject: string[];
    private readonly manager;
    constructor(ctx: Context);
    status(): Promise<import("./product-api.js").ProductResult>;
    operations(): Promise<import("./product-api.js").ProductResult>;
    /** Browser authorization URL is returned only through this user management endpoint. */
    manage(input: PapManagementRequest): Promise<import("./product-api.js").ProductResult>;
}
