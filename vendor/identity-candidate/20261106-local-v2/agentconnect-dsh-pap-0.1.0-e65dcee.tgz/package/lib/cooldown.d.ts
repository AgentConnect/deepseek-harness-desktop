import { PapError } from './errors.js';
import type { HttpResponse, PapState } from './types.js';
export declare const resourceCooldownKey: (companyId: string, resource: string) => string;
export declare const asCooldownKey: (companyId: string, issuer: string) => string;
export declare function responseHeader(response: HttpResponse, name: string): string | undefined;
/** Delta-seconds are stored as exact integer milliseconds, never capped to a shorter server window. */
export declare function retryAfterUntil(value: string | undefined, now: number): string;
export declare function remainingCooldownMs(state: PapState, key: string, now: number): bigint;
export declare function cooldownError(state: PapState, key: string, now: number): PapError;
export declare function assertCooldownElapsed(state: PapState, key: string, now: number): void;
export declare function recordCooldown(state: PapState, key: string, response: HttpResponse, now: number): void;
