import type { PapIdentityHost, PapSigningLease } from './host.js';
import type { Binding, Company, PublicJwk } from './types.js';
/** Structural subset of C's real ./protocol-client API. No native or generic signer fallback. */
export interface ProtocolKeyReference {
    keyRef: object;
    handle: string;
    purpose: 'pap_session' | 'pap_dpop';
    generation: number;
    publicJwk: PublicJwk;
    thumbprint: string;
}
export interface ProtocolSignerLease {
    readonly targetRef: object;
    getOAuthClientIdentity(): Promise<{
        clientId: string;
        keyId: string;
        algorithm: 'ES256';
        publicJwk: PublicJwk;
        redirectUris?: string[];
    }>;
    assertActive(): Promise<void>;
    signOAuthClientAssertion(targetRef: object): Promise<string>;
    bindPapScope(input: {
        userId: string;
        accountSlot?: string;
    }): object;
    createDelegatedKey(scopeRef: object, operationId: string): Promise<ProtocolKeyReference>;
    createDpopKey(scopeRef: object, operationId: string): Promise<ProtocolKeyReference>;
    restorePapKey(scopeRef: object, input: {
        handle: string;
        generation: number;
        purpose: 'pap_session' | 'pap_dpop';
    }): Promise<ProtocolKeyReference>;
    issuePapDelegation(scopeRef: object, input: {
        keyRef: object;
        ttlSeconds: number;
    }): Promise<string>;
    signPapSessionRequest(scopeRef: object, input: {
        keyRef: object;
        delegation: string;
        clientId: string;
        sid: string;
        sub: string;
        agentId?: string;
        httpMethod: string;
        httpUri: string;
        accessToken?: string;
    }): Promise<string>;
    signDpopProof(scopeRef: object, input: {
        keyRef: object;
        httpMethod: string;
        httpUri: string;
        accessToken?: string;
        nonce?: string;
    }): Promise<string>;
    retireTemporaryKey(scopeRef: object, keyRef: object): Promise<void>;
    dispose(): void;
}
export interface ProtocolIdentityClient {
    registerValidatedTarget(input: {
        identityRef: Binding['identityRef'];
        policyRef: string;
        discovery: {
            profile: 'pap_session' | 'pap_account';
            issuer: string;
            resource: string;
            tokenEndpoint?: string;
            revocationEndpoint?: string;
            companyId: string;
            metadataDigest: string;
            expiresAt: number;
            allowedEndpoints?: string[];
            sources: {
                resource: string;
                authorizationServer: string;
            };
        };
        requestedScopes: string[];
    }): Promise<ProtocolSignerLease>;
}
/** Bind to C from the installed Host Context; persist only the native handle and public descriptor. */
export declare class ProtocolIdentityHost implements PapIdentityHost {
    private readonly client;
    private readonly policyRef;
    private readonly rawLeases;
    private readonly leases;
    constructor(client: ProtocolIdentityClient, policyRef: string);
    dispose(): void;
    acquire(binding: Binding, company: Company, purpose: 'pap_session' | 'pap_account', resource: string, destination?: string, requestedScopes?: readonly string[]): Promise<PapSigningLease>;
}
