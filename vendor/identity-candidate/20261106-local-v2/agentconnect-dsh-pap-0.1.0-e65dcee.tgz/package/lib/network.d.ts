import type { HttpResponse, HttpTransport } from './types.js';
export declare function isPublicAddress(address: string): boolean;
export interface SafeHttpsOptions {
    timeoutMs?: number;
    maxBytes?: number;
    maxRequestBytes?: number;
    maxConcurrent?: number;
    /** Explicit isolated deployment/test exception; exact origins only. TLS still verified. */
    privateOrigins?: readonly string[];
    ca?: string | Buffer;
    /** Exact-origin mapping for isolated HTTPS component environments; requires privateOrigins. */
    portOverrides?: Readonly<Record<string, number>>;
    lookup?: (host: string) => Promise<{
        address: string;
        family: number;
    }[]>;
}
export declare class SafeHttpsTransport implements HttpTransport {
    private readonly options;
    private active;
    constructor(options?: SafeHttpsOptions);
    request(value: string, options?: Parameters<HttpTransport['request']>[1]): Promise<HttpResponse>;
}
