import { z } from 'zod';
import type { Binding, IdentityRef } from './types.js';
import type { DeviceManagementOperations } from './callback-handoff.js';
export declare const PAP_CONSUMER = "@agentconnect/dsh-pap/plugin";
export declare const PAP_MANAGER = "@agentconnect/dsh-pap/management-remote";
export declare const PAP_TOOLS = "@agentconnect/dsh-pap/tools";
/** C-owned capability. The caller is the actual installed F Context, never a wire name. */
export interface PapHostConsumer {
    resolveBinding(identityRef: IdentityRef, policyRef: string, profile: 'pap_session' | 'pap_account'): Promise<{
        binding: Binding;
        redirectUri?: string;
    }>;
    callbackManagementFor(input: {
        identityRef: IdentityRef;
        policyRef: string;
        targetRef: object;
    }): Promise<DeviceManagementOperations & {
        dispose(): void;
    }>;
    assertActive(): void | Promise<void>;
    dispose(): void;
}
export declare const identityReferenceSchema: z.ZodObject<{
    storeId: z.ZodString;
    identityId: z.ZodString;
    did: z.ZodString;
}, z.core.$strict>;
export declare const managementRequestSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    action: z.ZodLiteral<"identity/select">;
    reference: z.ZodObject<{
        storeId: z.ZodString;
        identityId: z.ZodString;
        did: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    action: z.ZodLiteral<"company/discover">;
    domain: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    action: z.ZodLiteral<"session/connect">;
    companyRef: z.ZodString;
    mode: z.ZodOptional<z.ZodEnum<{
        regular: "regular";
        anonymous: "anonymous";
    }>>;
    accountSlot: z.ZodOptional<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    action: z.ZodLiteral<"session/disconnect">;
    sessionRef: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    action: z.ZodLiteral<"operation/enable">;
    operationRef: z.ZodString;
    sessionRef: z.ZodString;
    scopes: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strict>, z.ZodObject<{
    action: z.ZodLiteral<"operation/disable">;
    operationRef: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    action: z.ZodLiteral<"account/sign-in">;
    sessionRef: z.ZodString;
    operationRef: z.ZodString;
    scopes: z.ZodArray<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    action: z.ZodLiteral<"account/collect">;
    transactionRef: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    action: z.ZodLiteral<"account/sign-out">;
    accountSlot: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    action: z.ZodLiteral<"account/refresh">;
    accountSlot: z.ZodString;
}, z.core.$strict>], "action">;
export type PapManagementRequest = z.infer<typeof managementRequestSchema>;
export declare const operationRequestSchema: z.ZodObject<{
    operationRef: z.ZodString;
    path: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    query: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    body: z.ZodOptional<z.ZodJSONSchema>;
}, z.core.$strict>;
export type PapOperationRequest = z.infer<typeof operationRequestSchema>;
export type ProductResult = {
    ok: true;
    value: unknown;
} | {
    ok: false;
    error: {
        code: string;
        retryAfterSeconds?: number | string;
    };
};
