import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
declare const contribution: TypertRemoteContribution;
export default contribution;
