/** Model Proxy client release gate for account recharge. */
/** Change only this value when the public recharge flow is ready to ship. */
export declare const AWIKI_RECHARGE_ENABLED = true;
/** Stable internal error used when a caller bypasses the guarded UI. */
export declare const AWIKI_RECHARGE_DISABLED_ERROR = "awiki_recharge_disabled";
//# sourceMappingURL=recharge-availability.d.ts.map