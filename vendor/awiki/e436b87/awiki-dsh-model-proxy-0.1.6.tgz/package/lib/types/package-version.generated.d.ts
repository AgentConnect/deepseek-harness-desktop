/** Generated from package.json by scripts/sync-package-versions.mjs. */
export declare const DSH_AWIKI_MODEL_PROXY_PACKAGE_VERSION: "0.1.6";
//# sourceMappingURL=package-version.generated.d.ts.map